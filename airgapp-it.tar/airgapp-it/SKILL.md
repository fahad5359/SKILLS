---
name: airgapp-it
description: Package what was just set up on this connected machine (a Helm app, k8s manifests, a terminal/CLI tool, a Python app, a Node/Go/Java app, a docker-compose stack, an AI model, OS packages, or anything else) into a self-contained offline bundle for an air-gapped site with a private Git repo (Gitea, GitLab, Forgejo...) and an air-gapped k3s server. It works from the conversation context and starts packaging right away; it doesn't open with a questionnaire. Use when the user says "airgapp it", "airgap this", "move this to my airgapped/offline place", "make an offline bundle", or asks how to get something into the air-gapped environment.
---

# airgapp-it

Turn something that works **here** (connected machine) into a bundle that installs and runs **there** (air-gapped site) with zero internet access.

## Rule #1: act, don't interview

The user calls this skill **after** setting something up with you. You already know what it is, so start packaging.

- **Don't open with questions.** Your first message is one or two lines saying what you're packaging, then you start working (tool calls in the same turn).
- **Copy what's here; don't redesign it.** The bundle reproduces the working setup: same components, chart/app versions, values, storage choices and ingress style. Don't offer alternatives (operator vs built-in DB, registry vs tarballs, extra backups). If you think something should change, put it in one line at the end under "Suggestions".
- **Unknown site facts don't block the build.** Hostnames, Gitea URL/org, TLS, storage class, image route and transfer limits are needed at **install** time, not build time. They go into `repo/site.env` with safe defaults and `CHANGE_ME` markers, and the user fills them in over there (see "Site values" below).
- **Reuse earlier decisions.** Read `~/airgap/target-profile.yaml` and earlier bundles (`~/airgap/bundles/*/MANIFEST.yaml`, `*/repo/site.env`) and follow what they decided. Placeholder values in an old bundle are not a reason to ask; carry them as `CHANGE_ME`.
- **Ask at the end, not the start.** Open items go in the final hand-over as a short list of what to fill in `site.env`, plus the Gitea question (Step 6).

**The only reasons to stop and ask before building:**
1. The conversation really doesn't show what to airgap (the skill was called cold). Then ask one line: *"What do you want airgapped?"*
2. Including something needs a **secret, license or credential** decision.
3. The download would be unusually big (more than ~20 GB). Say the size and ask whether to continue.

Everything else: pick the default, write it down in `MANIFEST.yaml` → `assumptions`, and keep going.

## The two places you can never reach

| Thing | What it is | What you can do |
|---|---|---|
| **Private Git repo** | Gitea, GitLab, Forgejo... on the air-gapped side | Nothing directly. You prepare files and a script that the user runs there. |
| **Air-gapped k3s server** | k3s cluster with no internet | Nothing directly. You write scripts the user runs there. They paste the output back if something fails. |

So the user is the only bridge. Everything you hand over must be **complete, pinned, checksummed, and explained step by step**. If one file is missing, the user has to make another trip. Treat "it fetches X on first start" as a bug in the bundle.

## Step 0: Know what you're packaging (from context)

Work it out from the conversation and the live system: what was installed, the commands you ran, the files you wrote, the release/namespace/venv/binary involved. Confirm it read-only (`helm list -A`, `kubectl get all -n <ns>`, the project dir, `command -v`...).

Then write one or two lines and start:

> Packaging Langfuse: chart 2.2.5 / app 4.80.0 with ClickHouse, Valkey, SeaweedFS and Postgres, as running in ns `langfuse`. Building for amd64 (same as here). Site-specific values go in `site.env` for you to fill in over there.

Include the pieces that were part of the setup in this conversation (e.g. client plugins or configs you set up together). Leave out unrelated things and list them under `left_out`.

## Step 1: Target facts: defaults, not questions

Only a few facts change **what gets downloaded**. Get them in this order: target profile → earlier bundles → the conversation → the default. Don't ask.

| Build-time fact | Default if unknown |
|---|---|
| CPU arch of k3s nodes/hosts | same as this machine (`uname -m`). Say it in the opening line so the user can correct it |
| OS / glibc for host binaries | use static/musl builds or a container image, which work on any distro |
| Python version on a host | bundle a standalone CPython (python-build-standalone) matching the version here, so the target's Python doesn't matter |
| k3s version | assume compatible with the chart's `kubeVersion`; verify.sh checks it over there |
| Transfer size limit | `finalize.sh --split 4G` (FAT32-safe) |

`~/airgap/target-profile.yaml` stores what's known about the site. Write to it when the user **tells** you facts (or pastes verify.sh output). Never hold up a build to fill it.

```yaml
# ~/airgap/target-profile.yaml  (all optional)
arch: amd64
k3s: {version: v1.31.4+k3s1, storage_class: local-path, ingress: traefik}
gitea: {url: https://git.airgap.lan, owner: platform, owner_type: org, repo: airgap-bundles}
image_mode: import        # import | registry
transfer: {method: usb, split: 4G}
```

### Site values (`repo/site.env`)

Every install-time fact lives in one file that the user edits on the air-gapped side. `new-bundle.sh` creates it; add app-specific keys (hostname, TLS, resource sizes...). Pre-fill from the profile and earlier bundles; otherwise use a safe default or `CHANGE_ME`.

- `install.sh` sources it and **refuses to run while a required key is still `CHANGE_ME`**. It prints exactly which ones are left.
- Values, manifests and scripts read from `site.env`. For Helm, install.sh passes them with `--set` or renders a `site-values.yaml` from them. Don't hard-code site guesses into `values.yaml`.
- Support both image routes in install.sh, switched by `IMAGE_MODE=import|registry` (default `import`, or the profile's value). Then the registry-vs-tarball choice never needs asking.

## Step 2: Discover everything it needs (read-only)

Inspect what is installed here and find **every** piece it needs. Read-only only: don't change the working setup.

Read the matching playbook. They are starting points, not limits:

| If the thing is... | Read |
|---|---|
| Helm release, k8s manifests, operator, anything on a cluster | [references/kubernetes-helm.md](references/kubernetes-helm.md) |
| Python app / script / tool | [references/python.md](references/python.md) |
| Terminal / CLI app, static binary, OS packages (apt/dnf/apk), systemd service | [references/binaries-cli.md](references/binaries-cli.md) |
| Node, Go source, Java/Maven, Rust, docker-compose, AI models, VS Code extensions, browser apps, anything else | [references/other-ecosystems.md](references/other-ecosystems.md) |
| How the bundle crosses over and lands in the Git repo / registry / k3s | [references/transfer-and-repo.md](references/transfer-and-repo.md) |

**For something none of these cover, you decide.** Work it out from first principles with these questions:

1. **Install-time fetches.** What does installing it download? (packages, images, charts, plugins, build deps, compilers, toolchains, sub-dependencies)
2. **Runtime fetches.** What does it pull after it starts? (sidecar/init images, operator-spawned images, plugins on first run, model weights, GeoIP/CVE/signature DBs, fonts, CDN JS/CSS, schema files, license checks, update checks, telemetry, ACME certs, NTP, external DNS names)
3. **Platform coupling.** CPU arch, OS/libc, kernel features, Python/Node/JDK version, k8s API versions, CRDs.
4. **State & config.** Config files, values, env vars, secrets (as placeholders), data to migrate, PVs.
5. **Prerequisites on the target.** What must already exist there? (container runtime, storage class, ingress, cert-manager, an operator, system libs). If the setup here relies on an operator (e.g. CloudNativePG), bundle the operator too unless an earlier bundle already shipped it. Then verify.sh/install.sh check for it.

**Research, don't guess.** Many projects publish official air-gap docs (Rancher, Longhorn, cert-manager, GitLab, Harbor, ArgoCD...). Look them up with WebSearch and follow them. When unsure what a component fetches, read its source/chart/docs or watch it: run it here with networking off (`docker run --network none`, `unshare -n`, a venv with `--no-index`) and see what breaks.

## Step 3: Inventory, then keep going

Write `MANIFEST.yaml` (format in [references/transfer-and-repo.md](references/transfer-and-repo.md)): every artifact with exact version, source, digest, arch, size and destination. Also `assumptions` (defaults you picked), `left_out` (with the reason), and `site_values` (the `site.env` keys to fill).

Post a short progress line (counts, size estimate) and **continue straight into downloading**. Only pause for the reasons in Rule #1.

## Step 4: Build the bundle

Create the skeleton with the helper:

```bash
~/.claude/skills/airgapp-it/scripts/new-bundle.sh <name> [version]
# -> ~/airgap/bundles/<name>-<version>-<YYYYMMDD>/
```

Layout:

```
<name>-<version>-<date>/
├── MANIFEST.yaml          # inventory + assumptions + left_out + site_values
├── README.md              # numbered steps for the air-gapped side, written for the user
├── repo/                  # SMALL text files -> go into the private Git repo
│   ├── site.env           #   the ONLY file the user edits over there
│   ├── install.sh         #   idempotent; sources site.env; stops on CHANGE_ME
│   ├── verify.sh          #   proves it works offline, prints PASS/FAIL per check
│   ├── uninstall.sh       #   clean rollback
│   ├── publish-to-gitea.sh#   optional upload into Gitea (Step 6)
│   └── config/ ...        #   values.yaml, manifests, .env.example, systemd units
├── payload/               # BIG binaries -> LFS / forge package registry / carried as files
│   ├── images/  charts/  wheels/  bin/  pkgs/  models/  src/
└── checksums.sha256       # sha256 of every file in repo/ and payload/
```

Helpers (use them, or do it by hand when they don't fit):

| Script | Does |
|---|---|
| `scripts/new-bundle.sh` | Creates the skeleton above, including `site.env`, the CHANGE_ME guard and `publish-to-gitea.sh` |
| `scripts/helm-images.sh` | Renders a chart with values and lists every image it references (`--live <ns>` for what's really running) |
| `scripts/save-images.sh` | Pulls images for the target platform and saves them as k3s-importable tars, records digests |
| `scripts/finalize.sh` | Writes `checksums.sha256`, prints sizes, packs into `.tar.zst`/`.tar.gz`, splits into parts if a size limit is given |
| `scripts/publish-to-gitea.sh` | Pushes images, charts, values/scripts (and optionally other files) into a Gitea/Forgejo org or user. Runs on the air-gapped side |

Rules while building:

- **Pin everything.** Exact versions; image digests (`repo@sha256:...`) alongside tags; hash-locked requirements. No `latest`, no ranges.
- **Match the target, not this machine.** Download for the target arch/OS (Step 1 defaults if unknown).
- **Rewrite references.** Point image repos, pip/npm indexes, helm repos and download URLs at the local bundle or the air-gapped registry. Turn off update checks and telemetry and set offline env vars (e.g. `HF_HUB_OFFLINE=1`, `PIP_NO_INDEX=1`).
- **No secrets in the bundle.** Ship `*.example` placeholders (or `CHANGE_ME` keys in `site.env`, or have install.sh generate random passwords on first run) and say in README where real values go. Ask before including any real credential, token or private key.
- **Include licenses / notices** for redistributed third-party artifacts when they ship with them.
- **Scripts on the target side** must be POSIX `sh`/`bash` that works without internet: `set -euo pipefail`, check prerequisites first, verify checksums before installing, be safe to re-run, back up anything they overwrite (`*.bak-<timestamp>`), and print what they did.

## Step 5: Prove it works offline, here

Before handing anything over, simulate the air gap on this machine where you can:

- Containers / k8s: `helm template` from the **local** chart `.tgz` with the bundle's values and check that every rendered image is in `payload/images/` (`helm-images.sh` diff). If a throwaway cluster is available (k3d/kind), load the images into it and install with no registry access.
- Python: fresh venv inside `docker run --network none python:<target-ver>` → `pip install --no-index --find-links payload/wheels -r requirements.lock` → run the app's smoke test.
- Binaries: run inside `docker run --network none <target-os-image>` to catch missing shared libs / glibc mismatch.
- Run the bundle's own `install.sh`/`verify.sh` in that sandbox if possible, with test values in a copy of `site.env`.

Report what you tested and what you could **not** test (e.g. real k3s version, real hardware). Don't claim it works on the target; you can't see it.

## Step 6: Gitea option (asked at the end)

`new-bundle.sh` already puts `publish-to-gitea.sh` in `repo/`, and `site.env` has `GITEA_URL`, `GITEA_OWNER`, `GITEA_REPO`. Pre-fill them from the profile or earlier bundles. Otherwise leave them as `CHANGE_ME`; that doesn't block anything.

In the final hand-over, ask this one question:

> Want me to upload the images, chart .tgz files and values under a Gitea repo?

- **Yes:** set `IMAGE_MODE=registry` in `site.env`, make install.sh pull charts/images from Gitea (`helm repo add` on `<url>/api/packages/<owner>/helm`, plus a k3s `registries.yaml` mirror with `rewrite` → `<owner>/$1`), put the publish step first in README, then re-run `finalize.sh`. No re-download needed.
- **No:** leave `IMAGE_MODE=import` and remove `publish-to-gitea.sh` from the README steps (it can stay in the bundle).

What the script does over there:
- `payload/charts/*.tgz` → the owner's Gitea Helm registry
- `payload/images/*.tar` → `<registry>/<owner>/<upstream path>:<tag>`, e.g. `docker.io/library/busybox:1.36` → `git.lan/platform/library/busybox:1.36`
- `repo/`, `MANIFEST.yaml`, `README.md`, `checksums.sha256`, plus a generated `PUBLISHED.md` → Git repo `<owner>/<repo>`, folder `bundles/<bundle-name>/`
- `--generic`: other payload files → generic packages. Every package is linked to the repo.

README command (reads `site.env`):
```bash
. repo/site.env && export GITEA_TOKEN=...   # never stored; scopes: write:package, write:repository, read:organization, read:user
./repo/publish-to-gitea.sh --url "$GITEA_URL" --owner "$GITEA_OWNER" --repo "$GITEA_REPO" --dry-run   # then again without --dry-run
```

**Organizations.** On many Gitea servers every repo lives under an **organization**, not the user's account. `GITEA_OWNER` is the org (never default it to the user's login). Its comment in `site.env` says so. The script's preflight checks that the owner exists, whether it's an org or a user, your membership, and your team's Packages: Write, and prints what's missing. `--create-repo` in an org also needs the `write:organization` token scope and a team with "Create repositories". Details: [references/transfer-and-repo.md](references/transfer-and-repo.md) → "Gitea".

The forge is GitLab or something else? Write an equivalent script for that API (registry table in transfer-and-repo.md), with the same safety rules: dry-run, token from env only, org-aware, idempotent.

## Step 7: Finalize and hand over

```bash
~/.claude/skills/airgapp-it/scripts/finalize.sh ~/airgap/bundles/<bundle> --split 4G
```

Then one compact message:

1. **Where the bundle is** (full path), total size and number of parts.
2. **Fill in over there:** the `site.env` keys still `CHANGE_ME`, one line each (what it is, example).
3. **Steps over there:** check parts → unpack → edit `site.env` → (publish to Gitea) → `install.sh` → `verify.sh`.
4. **Tested here / not tested.**
5. **Assumptions** you made (arch, versions), one line each, so the user can correct them.
6. **Suggestions** (optional, one line each): things you'd change but didn't, because you copied what's here.
7. The **Gitea question** (Step 6).
8. **If something fails:** run `verify.sh` and paste the output back.

If the user gives you site facts in the reply, save them to `~/airgap/target-profile.yaml` so the next bundle has them.

## Mindset

- The user called you to **do it**: package now, ask at the end.
- Air-gapping is about **closure**: the bundle plus the target's listed prerequisites must be enough. Hunt for the hidden download.
- **Mirror the working setup.** Prefer the project's **official offline path** over clever hacks.
- Prefer **fewer, bigger, verifiable** artifacts over many loose ones.
- Keep the working setup here untouched.
