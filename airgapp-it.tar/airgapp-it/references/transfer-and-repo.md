# Crossing the gap: MANIFEST, Git repo, registries, k3s

## MANIFEST.yaml format

```yaml
bundle: grafana-11.3.0-20261121
created: 2026-11-21
thing: "grafana helm release (ns monitoring)"
target: {arch: amd64, os: "Rocky 9", k3s: v1.31.4+k3s1}       # from target-profile.yaml
prerequisites:                     # must already exist over there
  - k3s with local-path storage
  - traefik ingress
artifacts:
  - kind: chart                    # chart|image|wheel|binary|pkg|model|src|config|other
    name: grafana
    version: 8.5.2
    source: https://grafana.github.io/helm-charts
    file: payload/charts/grafana-8.5.2.tgz
    sha256: <filled by finalize.sh / by you>
    dest: helm install (admin box)
  - kind: image
    name: docker.io/grafana/grafana:11.3.0
    digest: sha256:...
    platform: linux/amd64
    file: payload/images/docker.io_grafana_grafana_11.3.0.tar
    dest: k3s nodes (all) | registry.airgap.lan:5000
left_out:                          # deliberately not included, and why
  - name: grafana image-renderer
    why: disabled in values
open_questions: []
```

## What goes where on the air-gapped side

| Bundle part | Default destination | Alternatives |
|---|---|---|
| `repo/` (scripts, values, manifests, lockfiles, README, MANIFEST) | **Private Git repo**, e.g. `bundles/<name>/<version>/` or the app's own repo | GitOps source for ArgoCD/Flux |
| `payload/images/` | k3s nodes (import tarballs) | Forge container registry / Harbor / `registry:2` + `registries.yaml` |
| `payload/charts/` | admin box or k3s `static/charts` | Forge Helm registry (OCI or classic) |
| `payload/wheels/`, npm cache | target host | Forge PyPI / npm registry |
| `payload/bin/`, `pkgs/`, `models/`, `src/` | target host | Forge generic packages / Git LFS |

Keep big binaries **out of plain Git**. They bloat the repo forever. Use **Git LFS** (only if the forge has LFS enabled and the push machine has `git-lfs`), the **forge package registry**, or keep them as carried files with only `MANIFEST.yaml` + checksums in Git.

LFS `.gitattributes` example:
```
payload/** filter=lfs diff=lfs merge=lfs -text
```

## Forge package registries (verify against the user's forge version docs)

Both GitLab and Gitea/Forgejo ship registries that can be the "internet" of the air-gapped site:

| Type | GitLab | Gitea / Forgejo |
|---|---|---|
| Container | `docker push <gitlab-registry-host>/<group>/<project>/<img>:<tag>` (registry must be enabled) | `docker push <gitea-host>/<owner>/<img>:<tag>` |
| Helm | `POST /api/v4/projects/<id>/packages/helm/api/<channel>/charts` (form `chart=@x.tgz`) | `curl --user u:token -X POST --upload-file x.tgz https://<host>/api/packages/<owner>/helm/api/charts`, or `helm push x.tgz oci://<host>/<owner>` |
| PyPI | `twine upload --repository-url https://<host>/api/v4/projects/<id>/packages/pypi` | `twine upload --repository-url https://<host>/api/packages/<owner>/pypi` |
| npm | project/group npm registry | `https://<host>/api/packages/<owner>/npm/` |
| Generic files | `PUT /api/v4/projects/<id>/packages/generic/<name>/<ver>/<file>` | `PUT https://<host>/api/packages/<owner>/generic/<name>/<ver>/<file>` |

If the user wants this route on Gitea/Forgejo, use `scripts/publish-to-gitea.sh` (next section). For other forges, write `repo/publish-to-forge.sh` that uploads the payload using a token from an env var (never stored). Then install.sh pulls from the forge instead of local files.

## Gitea (tested on Gitea 28.4 with `scripts/publish-to-gitea.sh`)

**Ownership.** A package always belongs to an **owner, which is a user or an organization**, never to a repo. A repo can only be *linked* to it. Many sites keep everything under orgs, so `GITEA_OWNER` in `site.env` is the org name (from the profile, or `CHANGE_ME`). Never default it to the user's login.

| What | Format |
|---|---|
| Container image | `<host>/<owner>/<name>:<tag>`. The name may contain slashes (`platform/library/busybox`). Owner must be lowercase in the ref |
| Helm upload | `curl -u user:token -X POST --upload-file x.tgz <url>/api/packages/<owner>/helm/api/charts` (201 new, 409 exists) |
| Helm install | `helm repo add <alias> <url>/api/packages/<owner>/helm --username u --password <token>` |
| Generic file | `PUT <url>/api/packages/<owner>/generic/<pkg>/<ver>/<file>`. Names use only `A-Za-z0-9.+-_`. 409 = exists (delete before replacing) |
| Link to repo | `POST <url>/api/v1/packages/<owner>/<type>/<name>/-/link/<repo>` (name URL-encoded, `/` → `%2F`). 400 if already linked |
| Owner type | `GET /api/v1/orgs/<o>` 200 → org; else `GET /api/v1/users/<o>` |
| Org membership | `GET /api/v1/orgs/<org>/members/<login>` 204 = member |
| Team rights | `GET /api/v1/user/teams`. Look for `units_map."repo.packages": "write"` for that org |
| Create repo | org: `POST /api/v1/orgs/<org>/repos` (token needs `write:organization` and the team needs `can_create_org_repo`); user: `POST /api/v1/user/repos` |

**Permissions.** Writing to an org's packages needs membership in a team with Packages: Write. That team right covers *all* packages of the org. Reading private-org packages needs org membership, so k3s nodes need `auth` in `registries.yaml`, using a read-only token (`read:package`) from a service account.

**Token scopes** for the publish script: `write:package`, `write:repository`, `read:organization`, `read:user`. Add `write:organization` only for `--create-repo` under an org.

**Registry URL.** Docker/k3s get the auth realm from Gitea's `ROOT_URL`. If `ROOT_URL` is wrong (e.g. http vs https, or an internal name), image pushes and pulls fail even though the API works.

**Name collisions.** Images are stored as `<owner>/<upstream path without registry host>`, so `docker.io/foo/x` and `quay.io/foo/x` would collide. If a bundle has such a pair, push one with `--skip-images` and push the other by hand under a prefixed path (e.g. `<owner>/quay.io/foo/x`), and give that registry's mirror a matching `rewrite`.

k3s mirror to Gitea, keeping the upstream names in manifests:
```yaml
mirrors:
  docker.io:
    endpoint: ["https://git.airgap.lan"]
    rewrite:
      "^(.*)$": "platform/$1"     # docker.io/library/busybox -> platform/library/busybox
  quay.io:
    endpoint: ["https://git.airgap.lan"]
    rewrite:
      "^(.*)$": "platform/$1"
configs:
  "git.airgap.lan":
    auth: {username: <svc-user>, password: <read:package token>}
    # tls: {ca_file: /etc/rancher/k3s/gitea-ca.crt}
```

## Pushing images to a registry over there

No Docker on the target? Bundle a static `crane` (go-containerregistry) or `skopeo` in `payload/bin/`:
```bash
crane push payload/images/<img>.tar registry.airgap.lan:5000/<path>:<tag>
skopeo copy docker-archive:payload/images/<img>.tar docker://registry.airgap.lan:5000/<path>:<tag>
```
Keep the **same repository path** as upstream (e.g. `.../grafana/grafana:11.3.0`). Then `registries.yaml` mirrors work without editing values.

## Landing images in k3s

**1. Tarball import, no registry.** On *every* node that may run the pods:
```bash
sudo mkdir -p /var/lib/rancher/k3s/agent/images/
sudo cp payload/images/*.tar /var/lib/rancher/k3s/agent/images/    # auto-imported at k3s start
sudo k3s ctr -n k8s.io images import payload/images/<img>.tar      # or import now, no restart
sudo k3s crictl images | grep <name>                               # check
```
Images keep their original names, so manifests don't change. Set `imagePullPolicy: IfNotPresent`. Images that aren't in use can be garbage-collected under disk pressure, which is a reason to prefer a registry for long-lived setups. On recent k3s, the **embedded registry mirror** (`--embedded-registry`, Spegel) shares imported images between nodes. Check the target k3s version's docs.

**2. Private registry + mirrors.** `/etc/rancher/k3s/registries.yaml` on every node, then restart k3s / k3s-agent:
```yaml
mirrors:
  docker.io:
    endpoint: ["https://registry.airgap.lan:5000"]
  quay.io:
    endpoint: ["https://registry.airgap.lan:5000"]
  ghcr.io:
    endpoint: ["https://registry.airgap.lan:5000"]
  registry.k8s.io:
    endpoint: ["https://registry.airgap.lan:5000"]
configs:
  "registry.airgap.lan:5000":
    tls:
      ca_file: /etc/rancher/k3s/registry-ca.crt
    # auth: {username: ..., password: ...}   # placeholder only, never in the bundle
```
Back up an existing `registries.yaml` before changing it, and **merge** with it rather than replace it.

## Packing, carrying, checking

- `scripts/finalize.sh <bundle> [--split 4G]` writes `checksums.sha256` (inside) and `<bundle>.parts.sha256` (next to the archive), and splits for FAT32 sticks (4 GB file limit) or forge upload limits.
- Over there: `sha256sum -c <bundle>.parts.sha256 && cat <bundle>.tar.*.part* | tar -x ...` then `cd <bundle> && sha256sum -c checksums.sha256`.
- README must say how to reassemble and verify, with exact commands.

## Updates and repeat trips

- Bundles are versioned (`<name>-<version>-<date>`). For an upgrade, build a new bundle. If size matters, ship a **delta** (only new images/wheels, listed in MANIFEST as `delta_from: <previous bundle>`).
- Keep `~/airgap/bundles/` here as the record of what was sent. Don't delete old bundles without asking.

## Feedback loop

You can't see the target. Make `verify.sh` print clear `PASS`/`FAIL` lines plus one diagnostics command for each failure (e.g. `kubectl describe pod`, `journalctl -u <svc> -n 50`). Ask the user to paste its output back. Fix the bundle, bump the bundle version, and ship only what changed.
