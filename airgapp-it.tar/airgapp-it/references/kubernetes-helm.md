# Playbook: Helm releases, k8s manifests, operators → air-gapped k3s

## Discover

```bash
helm list -A -o json                                  # release, namespace, chart-version, app_version
helm get metadata <rel> -n <ns>                       # chart name/version (helm ≥ 3.14)
helm get values   <rel> -n <ns> -o yaml               # user-supplied values  -> ship these
helm get values   <rel> -n <ns> -a -o yaml            # all computed values   -> for reference only
helm get manifest <rel> -n <ns>                       # what was actually applied
helm get hooks    <rel> -n <ns>                       # hook jobs (often extra images!)
helm repo list; helm search repo <chart> --versions   # find which repo/OCI the chart came from
kubectl get crd | grep -i <app>                       # CRDs the app owns
```

The release doesn't record which repo the chart came from. Find it, without asking, from: the conversation (you probably installed it), `helm repo list` / `helm search repo <chart> --versions`, shell history (`grep -h 'helm .*install\|helm repo add' ~/.bash_history ~/.zsh_history`), or Artifact Hub by chart name + version.

## Collect

1. **Chart**, exact version, packaged with its subcharts:
   `helm pull <repo>/<chart> --version <v> -d payload/charts/` (or `helm pull oci://... --version <v>`).
   Check `tar tzf` shows `charts/` subcharts; if the chart is a local dir, `helm dependency build` then `helm package`.
2. **Values**: `helm get values` (user-supplied only) → `repo/config/values.yaml`. Strip secrets into `values-secrets.example.yaml`.
3. **Images**: use every source and merge them:
   - `scripts/helm-images.sh payload/charts/<chart>.tgz -f repo/config/values.yaml -n <ns>`: rendered templates, hooks and tests.
   - `scripts/helm-images.sh --live <ns>`: what is really running, **including operator-spawned pods** that the chart never renders.
   - grep the chart and the operator's Deployment for `RELATED_IMAGE_`, `--*-image=`, `image` keys inside ConfigMaps/CRs, and default image fields in CRD specs.
   - Images referenced by tag `latest` → pin to the digest currently running (`kubectl get pod -o jsonpath='{..imageID}'`).
4. **Save images** for the target arch: `scripts/save-images.sh payload/images images.txt linux/amd64` (one tar per image, digests recorded).
5. **CRDs**: usually inside the chart (`crds/`). If the app needs CRDs from **another** chart/operator (cert-manager, prometheus-operator ServiceMonitor, Gateway API), that's a prerequisite: bundle it too or list it in README prerequisites.
6. **Tools for the target**: `helm` binary (static, target arch) in `payload/bin/` if the target admin box lacks it. Optionally `crane`/`skopeo` to push to a registry.
7. **Other cluster objects** that aren't in the chart but the app needs (Secrets, ConfigMaps, PVCs, Ingress, NetworkPolicies, ServiceAccounts made by hand): export with `kubectl get ... -o yaml`, clean `metadata.uid/resourceVersion/creationTimestamp/managedFields` and `status`, save them to `repo/config/extra/`. Secrets go in as `.example` placeholders only.

## Values rewrites for the air gap

- `imagePullPolicy: IfNotPresent` everywhere (an `Always` policy fails with no registry).
- `global.imageRegistry` / `image.registry` → the air-gapped registry, **or** leave names untouched and use k3s `registries.yaml` mirrors (see transfer-and-repo.md). Mirrors mean less editing of values.
- Turn off anything that phones home: update checks, telemetry, analytics, `grafana.ini [analytics]`, plugin auto-installs (`GF_INSTALL_PLUGINS`: bundle the plugin zips instead), external auth/OIDC endpoints.
- cert-manager with ACME/Let's Encrypt won't work → CA issuer or pre-made TLS secrets.
- `storageClassName` → the target's (k3s default `local-path`).
- Ingress class / hosts → the target's domain.

## Install on the target (pick one, write it into install.sh)

**A. helm CLI** (admin box with kubeconfig):
```bash
helm upgrade --install <rel> "$PAYLOAD_DIR/charts/<chart>-<v>.tgz" \
  -n <ns> --create-namespace -f config/values.yaml [-f values-secrets.yaml] --wait --timeout 10m
```

**B. k3s helm-controller, no helm binary needed** (run on a k3s server node):
```bash
sudo cp "$PAYLOAD_DIR/charts/<chart>-<v>.tgz" /var/lib/rancher/k3s/server/static/charts/
sudo cp config/<rel>-helmchart.yaml /var/lib/rancher/k3s/server/manifests/
```
```yaml
apiVersion: helm.cattle.io/v1
kind: HelmChart
metadata: {name: <rel>, namespace: kube-system}
spec:
  chart: https://%{KUBERNETES_API}%/static/charts/<chart>-<v>.tgz
  targetNamespace: <ns>
  createNamespace: true
  valuesContent: |-
    # paste values.yaml here
```
(The helm-controller job image `rancher/klipper-helm` is part of the standard k3s air-gap images.)

**C. Plain manifests**: `kubectl apply -k` / `-f` from `repo/config/`. Good for GitOps (ArgoCD/Flux pointed at the private Git repo; their images must be air-gapped too).

## Images on the k3s nodes

See transfer-and-repo.md → "Landing images in k3s". Images must be present on **every node that may schedule the pod** (or use a registry / the k3s embedded registry mirror).

## verify.sh ideas

- every image in `MANIFEST.yaml` exists: `sudo k3s crictl images | grep ...` (or registry API `/v2/<repo>/tags/list`)
- `kubectl -n <ns> rollout status` for each deploy/sts/ds
- no pod in `ImagePullBackOff`/`ErrImagePull`: `kubectl get pods -n <ns> --no-headers | grep -E 'ImagePull|ErrImage'` must be empty
- app health endpoint via `kubectl port-forward` or `kubectl run --rm curl` (bundle the curl image if you use one)
- `kubectl get events -n <ns> --field-selector type=Warning`

## Special case: the thing *is* k3s (install/upgrade k3s itself)

From the k3s GitHub release matching the target version and arch: `k3s` (or `k3s-arm64`) binary, `k3s-airgap-images-<arch>.tar.zst`, and the `install.sh` from get.k3s.io. On the target:
```bash
sudo mkdir -p /var/lib/rancher/k3s/agent/images/
sudo cp k3s-airgap-images-amd64.tar.zst /var/lib/rancher/k3s/agent/images/
sudo install -m 755 k3s /usr/local/bin/k3s
INSTALL_K3S_SKIP_DOWNLOAD=true ./install.sh      # add server/agent flags as needed
```
RHEL-family with SELinux also needs the `k3s-selinux` + `container-selinux` RPMs (bundle them). Follow the k3s air-gap docs for the exact version.
