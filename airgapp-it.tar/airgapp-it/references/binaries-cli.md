# Playbook: terminal/CLI apps, binaries, OS packages, services

## Discover how it got here

```bash
command -v <tool>; readlink -f "$(command -v <tool>)"
file "$(readlink -f "$(command -v <tool>)")"      # static? dynamic? arch?
ldd  "$(readlink -f "$(command -v <tool>)")"      # shared libs (dynamic only)
objdump -T <bin> | grep -o 'GLIBC_[0-9.]*' | sort -uV | tail -1   # min glibc needed
dpkg -S <path> / rpm -qf <path>                    # came from an OS package?
ls ~/.local/bin ~/go/bin ~/.cargo/bin /usr/local/bin ~/.local/share/pipx /snap/bin   # other installers
<tool> --version
```

Then find its **extras**: config (`~/.config/<tool>`, `/etc/<tool>`), plugins (krew, tmux/tpm, nvim lazy/packer, zsh/oh-my-zsh, asdf/mise), themes/skins, shell completions, man pages, data dirs, systemd units (`systemctl cat <svc>`), cron jobs, and env vars in shell rc files.

## By kind

**Static binary (most Go/Rust tools: k9s, helm, kubectl, yq, jq, ripgrep, lazygit...)**
Download the **target-arch** release asset from the project's official release page with its checksum file. Verify `sha256sum -c`, and cosign/GPG signatures when the project publishes them. Record the URL and sha256 in MANIFEST. Don't copy this machine's binary unless the arches match and you know it's static.

**Dynamic binary**
Compare the min `GLIBC_x.y` needed with the target's `ldd --version`. If target glibc is older: use the project's musl/static build, build it in a container of the target OS, or bundle it as a container image.

**OS packages (apt / dnf / apk)**
Resolve in a container of the **exact target OS release** so the dependency set matches:
```bash
# Debian/Ubuntu
docker run --rm -v "$PWD/payload/pkgs:/out" ubuntu:24.04 sh -c '
  apt-get update && apt-get install -y --download-only --no-install-recommends <pkgs> &&
  cp /var/cache/apt/archives/*.deb /out/ &&
  apt-get install -y dpkg-dev && cd /out && dpkg-scanpackages . /dev/null | gzip -9 > Packages.gz'
# target: echo "deb [trusted=yes] file:$PAYLOAD_DIR/pkgs ./" > /etc/apt/sources.list.d/airgap.list; apt-get update; apt-get install <pkgs>

# RHEL/Rocky/Alma
docker run --rm -v "$PWD/payload/pkgs:/out" rockylinux:9 sh -c '
  dnf install -y dnf-plugins-core createrepo_c &&
  dnf download --resolve --alldeps --destdir /out <pkgs> && createrepo_c /out'
# target: a .repo file with baseurl=file://$PAYLOAD_DIR/pkgs gpgcheck=1 (or 0 with user consent), then dnf install <pkgs>

# Alpine
docker run --rm -v "$PWD/payload/pkgs:/out" alpine:3.20 sh -c 'apk update && apk fetch -R -o /out <pkgs>'
# target: apk add --allow-untrusted --no-network /path/*.apk  (or a local repo index)
```
A minimal container downloads **more** deps than the target needs. That's fine; the package manager skips installed ones. install.sh installs only the named packages (never a full upgrade), and the README warns if one would replace a core system package (glibc, openssl, systemd).

**Language-installed tools** (`pipx`, `npm -g`, `cargo install`, `go install`): treat as that ecosystem (python.md / other-ecosystems.md), or produce one static binary here (`CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build`, `cargo build --target x86_64-unknown-linux-musl`).

**Snap / Flatpak / AppImage**: AppImage is already one file. Snap: `snap download <name> --channel=...` gives `.snap` + `.assert`; target runs `snap ack x.assert && snap install x.snap`. Flatpak: `flatpak create-usb` / bundle.

**Services**: include the unit file, an env file template, the user/group creation, directories and permissions, firewall ports, and logrotate. install.sh enables it, verify.sh checks `systemctl is-active` and the port/health.

## Install on the target

Pick one: `/usr/local/bin` (root) or `~/.local/bin` (user). `install -m 0755`, back up an existing binary first (`<bin>.bak-<ts>`), install completions/man pages, copy config only if none exists (or merge with a `.new` file and tell the user).

## Prove it here

```bash
docker run --rm --network none --platform linux/<arch> -v "$BUNDLE:/b" <target-os-image> \
  sh -c 'sh /b/repo/install.sh && sh /b/repo/verify.sh'
```
That catches missing libs, glibc mismatches and "first run downloads stuff" behaviour.
