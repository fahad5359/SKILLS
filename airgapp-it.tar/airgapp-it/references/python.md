# Playbook: Python apps, scripts, tools

## Discover

- Python version the app needs vs. the **target's** Python (`python3 -V` there). Different minor version → different wheels.
- Target arch + glibc (`ldd --version`) → which `manylinux_X_Y` wheels will load. musl (Alpine) → `musllinux` wheels.
- Dependency source of truth, in this order: `uv.lock` / `poetry.lock` / `requirements*.txt` with pins / `pyproject.toml`. If nothing is pinned, freeze the **working** venv: `.venv/bin/pip freeze --exclude-editable`.
- Extras, optional deps, dev vs runtime deps: ship only what runs, unless the user wants to develop there too.
- Native deps: packages with no wheel for the target (sdist only) need a compiler there **or** a wheel built here. Build it here.
- Non-Python system libs (libpq, libgomp, CUDA, ffmpeg, tesseract): see binaries-cli.md for OS packages.

## Hidden runtime downloads to hunt for

`nltk.download`, Hugging Face models/tokenizers (`HF_HOME`, set `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`), `sentence-transformers`, spaCy models (they're pip packages from a URL), `tiktoken` encodings (`TIKTOKEN_CACHE_DIR`), `torch.hub`, `playwright install` browsers (`PLAYWRIGHT_BROWSERS_PATH`), `easyocr`/`paddle` weights, `matplotlib` fonts, pre-commit hooks, Jupyter extensions, `pip install` calls inside the code. Grep the code and site-packages for `download`, `urlopen`, `requests.get`, `hf_hub_download`, `from_pretrained`.

Also: **torch/CUDA**. Pick the right wheel variant (cpu vs cuXXX) for the target GPU/driver. These wheels are huge; tell the user the size.

## Collect wheels for the TARGET (not this machine)

```bash
PYV=3.11; ABI=cp311
pip download -r requirements.lock -d payload/wheels \
  --only-binary=:all: --implementation cp --python-version $PYV --abi $ABI \
  --platform manylinux_2_28_x86_64 --platform manylinux2014_x86_64 --platform any
# also the installer basics:
pip download pip setuptools wheel -d payload/wheels --only-binary=:all: --python-version $PYV --platform any
# the app itself (if it's a package):
pip wheel . --no-deps -w payload/wheels
```

Use `--platform manylinux_2_28_aarch64` etc. for arm64. Only list manylinux tags the target glibc supports (2_28 needs glibc ≥ 2.28).

If `--only-binary` fails for a package, it has no wheel for that target. Build it in a container that matches the target:
```bash
docker run --rm --platform linux/amd64 -v "$PWD:/w" -w /w python:3.11-slim-bookworm \
  sh -c 'pip wheel --no-deps <pkg>==<ver> -w payload/wheels'
# for portable wheels use quay.io/pypa/manylinux_2_28_x86_64 + auditwheel repair
```

**uv alternative** (if uv is available): `uv pip compile pyproject.toml --python-version 3.11 --python-platform x86_64-manylinux_2_28 --generate-hashes -o requirements.lock`, then `pip download` as above. Hash-locked = tamper-evident.

## If the target lacks the needed Python

Bundle a relocatable CPython from **python-build-standalone** (astral-sh/python-build-standalone releases, `cpython-<ver>+<date>-<arch>-unknown-linux-gnu-install_only.tar.gz`) into `payload/bin/`. Extract to `/opt/python-<ver>` on the target. No root/compilers needed. Pin the exact release asset + sha256.

## Or: ship it as a container

If it will run on k3s anyway, build an image here with everything baked in (wheels, models, `HF_HUB_OFFLINE=1`) and follow kubernetes-helm.md. Often the simplest closure.

## Install on the target (install.sh)

```bash
PY=${PY:-python3}
$PY -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --no-index --find-links "$PAYLOAD_DIR/wheels" --upgrade pip setuptools wheel
"$APP_DIR/.venv/bin/pip" install --no-index --find-links "$PAYLOAD_DIR/wheels" [--require-hashes] -r config/requirements.lock
"$APP_DIR/.venv/bin/pip" install --no-index --find-links "$PAYLOAD_DIR/wheels" <app-package>
```
Plus `.env.example`, a systemd unit or wrapper script, model/data dirs, and offline env vars.

## Prove it here

```bash
docker run --rm --network none --platform linux/amd64 -v "$BUNDLE:/b" python:3.11-slim \
  sh -c 'python -m venv /v && /v/bin/pip install --no-index --find-links /b/payload/wheels -r /b/repo/config/requirements.lock && /v/bin/python -c "import <app>; print(\"ok\")"'
```
Use the target's distro image when possible (e.g. `rockylinux:9` + bundled Python) to also catch glibc and system-lib gaps. Then run the app's real smoke test with `--network none`.

## Private Git repo angle

Small: `requirements.lock`, `pyproject.toml`, config, scripts → `repo/`. Wheels → LFS, or the forge's **PyPI registry** (GitLab and Gitea both have one). Then the target installs with `pip install --index-url https://<forge>/.../simple`. See transfer-and-repo.md.
