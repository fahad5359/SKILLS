# Playbook: everything else

Not exhaustive. For anything not here, apply the five questions in SKILL.md Step 2 and look up the project's official offline/air-gap docs.

## Source code repos → private Git repo

Moving a Git repo (with history) is the most common job. Use **git bundle**:
```bash
git -C <repo> bundle create payload/src/<name>.bundle --all
git bundle verify payload/src/<name>.bundle
# target: git clone <name>.bundle <name> && cd <name> && git remote set-url origin <private-forge-url> && git push --all && git push --tags
```
Submodules: bundle each one, and rewrite `.gitmodules` URLs to the private forge. LFS objects: `git lfs fetch --all` and copy `.git/lfs/objects`, or push LFS separately. For an update: `git bundle create upd.bundle <last-sent-tag>..main`.

## Node.js

- Runtime: official `node-v<ver>-linux-<arch>.tar.xz` in `payload/bin/`.
- Deps: `npm ci` with lockfile in a container matching the target (native modules!), then either ship `node_modules` or ship an npm cache:
  `npm ci --cache ./npm-cache` → target `npm ci --offline --cache ./npm-cache`. pnpm: `pnpm fetch` + `pnpm install --offline`. yarn berry: offline mirror / zero-installs.
- Postinstall downloaders: puppeteer/playwright browsers, `sharp` (libvips), `esbuild`/`swc`/`turbo` per-platform optional deps, cypress, node-gyp headers (`npm_config_nodedir`). Set their env vars to local paths.
- Or build here: ship `dist/` + production `node_modules`, or one container image.

## Go / Rust source

- Easiest: build the binary here for the target (`CGO_ENABLED=0 GOOS GOARCH`, `--target *-musl`) → binaries-cli.md.
- To build there: `go mod vendor` + Go toolchain tarball (`GOFLAGS=-mod=vendor`, `GOTOOLCHAIN=local`). Rust: `cargo vendor` + `.cargo/config.toml` source replacement + rustup offline toolchain.

## Java / JVM

- JDK tarball (Temurin etc., target arch).
- Maven: `mvn dependency:go-offline -Dmaven.repo.local=./m2` (plugins too!), target `mvn -o -Dmaven.repo.local=./m2`. Gradle: populate `GRADLE_USER_HOME` with `--refresh-dependencies` builds, target `--offline`, and bundle the gradle distribution zip the wrapper wants (`distributionUrl` → file path).
- Or ship a fat jar / container image.

## docker-compose stacks

- `docker compose config --images` → save-images.sh. Pin each image to a digest in the compose file.
- Bind-mounted config/data dirs, `.env` (→ `.env.example`), build contexts (build here, ship the image).
- Target has no Docker but has k3s? Offer converting to k8s manifests/Helm (kompose as a start, then clean up) and follow kubernetes-helm.md.
- Target needs Docker Engine itself? → OS packages (binaries-cli.md) or static docker binaries.

## AI models

- **Ollama**: bundle the `ollama` binary or image, plus the model's files from `~/.ollama/models` (the `manifests/registry.ollama.ai/library/<model>/<tag>` file and every `blobs/sha256-*` it references). Target: copy into `$OLLAMA_MODELS`, then `ollama list` should show it.
- **Hugging Face**: `huggingface-cli download <repo> --revision <commit-sha> --local-dir payload/models/<name>` (check license/gated access), then on the target `HF_HUB_OFFLINE=1` and point the app at the local path.
- On k3s: preload into a PVC (a job that copies from a hostPath / a tar), or bake into an image if small enough, or a hostPath on a pinned node.
- Model files are huge: give the user sizes early.

## Editors / dev tools

- VS Code / code-server extensions: `.vsix` from the marketplace or Open VSX, pinned versions; `code --install-extension x.vsix`.
- Neovim: plugin manager lockfile + clone each plugin repo at the locked commit (or tar `~/.local/share/nvim/lazy`), Mason tools/LSP binaries, treesitter parsers compiled for the target arch.
- Shell setups: oh-my-zsh/plugins as git bundles, fonts.

## Web apps / dashboards

- CDN links (`<script src="https://cdn...">`, Google Fonts) → vendor locally and rewrite the HTML.
- Map tiles, GeoIP DBs, CVE/vuln DBs (Trivy `--download-db-only` + `--skip-db-update`), antivirus signatures, OSM data: these need a **refresh plan**. Note it in README.

## Databases & data

Dumps (`pg_dump -Fc`, `mysqldump`, `mongodump`), exported volumes, and the restore steps. Check that the major versions are compatible with the target.

## Cross-cutting things the target needs

- **Trust**: internal CA certs for the registry/forge (`/usr/local/share/ca-certificates`, k3s `registries.yaml` `ca_file`).
- **DNS / hostnames** the app expects. **Time sync** (NTP inside the air gap), since TLS breaks on clock drift.
- **Licenses** that need online activation: flag them early, they can block the whole plan.
