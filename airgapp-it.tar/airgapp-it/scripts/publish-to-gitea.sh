#!/usr/bin/env bash
# publish-to-gitea.sh: push an airgapp-it bundle into Gitea / Forgejo.
# Runs on the AIR-GAPPED side (the machine that can reach Gitea).
#
#   payload/charts/*.tgz   -> Gitea Helm registry        (owner = org or user)
#   payload/images/*.tar   -> Gitea container registry    <registry>/<owner>/<upstream path>:<tag>
#   payload/{bin,pkgs,wheels,models,src}/* -> Gitea generic packages   (only with --generic)
#   repo/ + MANIFEST.yaml + README.md + checksums.sha256 -> Git repo <owner>/<repo>, folder --path
#   every package is linked to <owner>/<repo> so it shows on the repo's Packages tab
#
# Usage:
#   export GITEA_TOKEN=...     # personal access token, scopes: write:package, write:repository, read:organization, read:user
#                              # + write:organization only if --create-repo under an org (and your team needs
#                              #   "Create repositories" = can_create_org_repo, or an org owner creates the repo)
#   ./publish-to-gitea.sh --url https://git.example.lan --owner <org-or-user> --repo <repo> [options]
#
# Options:
#   --bundle DIR        bundle root (default: the dir above this script, if it has payload/)
#   --registry HOST     container registry host (default: host[:port] of --url)
#   --path DIR          folder inside the Git repo (default: bundles/<bundle-name>)
#   --branch NAME       default: main
#   --create-repo       create <owner>/<repo> (private) if it doesn't exist
#   --generic           also upload other payload files as generic packages
#   --skip-images | --skip-charts | --skip-git | --no-link
#   --image-tool T      skopeo | crane | docker (default: first one found, in that order)
#   --ca-file FILE      CA cert for a self-signed Gitea | --insecure (skip TLS verify)
#   --dry-run           show what would happen, change nothing
set -euo pipefail

URL=""; OWNER=""; REPO=""; BUNDLE=""; REGISTRY=""; RPATH=""; BRANCH=main
CREATE=0; GENERIC=0; DO_IMG=1; DO_CHART=1; DO_GIT=1; DO_LINK=1; TOOL=""; CA=""; INSECURE=0; DRY=0
while (($#)); do case "$1" in
  --url) URL="${2%/}"; shift 2;;            --owner) OWNER="$2"; shift 2;;
  --repo) REPO="$2"; shift 2;;              --bundle) BUNDLE="$2"; shift 2;;
  --registry) REGISTRY="$2"; shift 2;;      --path) RPATH="$2"; shift 2;;
  --branch) BRANCH="$2"; shift 2;;          --create-repo) CREATE=1; shift;;
  --generic) GENERIC=1; shift;;             --skip-images) DO_IMG=0; shift;;
  --skip-charts) DO_CHART=0; shift;;        --skip-git) DO_GIT=0; shift;;
  --no-link) DO_LINK=0; shift;;             --image-tool) TOOL="$2"; shift 2;;
  --ca-file) CA="$2"; shift 2;;             --insecure) INSECURE=1; shift;;
  --dry-run) DRY=1; shift;;
  -h|--help) sed -n '2,30p' "$0"; exit 0;;
  *) echo "unknown option: $1" >&2; exit 2;;
esac; done

die()  { printf 'FAIL  %s\n' "$*" >&2; exit 1; }
ok()   { printf 'OK    %s\n' "$*"; }
warn() { printf 'WARN  %s\n' "$*" >&2; }
step() { printf '\n== %s ==\n' "$*"; }
dry()  { ((DRY)) && { printf 'DRY   %s\n' "$*"; return 0; }; return 1; }

[[ -n "$URL" && -n "$OWNER" && -n "$REPO" ]] || die "need --url, --owner and --repo (see --help)"
[[ -n "${GITEA_TOKEN:-}" ]] || die "set GITEA_TOKEN in the environment (it is never written to disk)"
HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ -z "$BUNDLE" ]]; then [[ -d "$HERE/../payload" ]] && BUNDLE="$HERE/.." || die "use --bundle <dir>"; fi
BUNDLE="$(cd "$BUNDLE" && pwd)"; BNAME="$(basename "$BUNDLE")"
RPATH="${RPATH:-bundles/$BNAME}"
HOSTPORT="${URL#*://}"; HOSTPORT="${HOSTPORT%%/*}"
REGISTRY="${REGISTRY:-$HOSTPORT}"
OWNER_LC="$(printf '%s' "$OWNER" | tr '[:upper:]' '[:lower:]')"   # image refs must be lowercase

CURL=(curl -sS -u "x:$GITEA_TOKEN")      # placeholder user, replaced once we know the login
TLS=(); GIT_TLS=()
[[ -n "$CA" ]] && { TLS=(--cacert "$CA"); GIT_TLS=(-c "http.sslCAInfo=$CA"); }
((INSECURE)) && { TLS=(-k); GIT_TLS=(-c http.sslVerify=false); }
code() { "${CURL[@]}" "${TLS[@]}" -o "$TMP/resp" -w '%{http_code}' "$@" || echo 000; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
export DOCKER_CONFIG="$TMP/docker"; mkdir -p "$DOCKER_CONFIG"   # registry login lives only for this run, never in ~/.docker

# ---------------------------------------------------------------- preflight
step "preflight"
c=$(code "$URL/api/v1/version"); [[ $c == 200 ]] || die "cannot reach $URL/api/v1/version (HTTP $c)"
ok "Gitea $(sed 's/.*"version":"\([^"]*\)".*/\1/' "$TMP/resp") at $URL"
c=$(code "$URL/api/v1/user"); [[ $c == 200 ]] || die "token rejected (HTTP $c). Token needs scopes write:package, write:repository, read:organization, read:user"
LOGIN="$(sed 's/.*"login":"\([^"]*\)".*/\1/' "$TMP/resp")"
CURL=(curl -sS -u "$LOGIN:$GITEA_TOKEN")
ok "logged in as $LOGIN"

# Owner: in most setups repos live under an ORGANIZATION, not your user.
if [[ $(code "$URL/api/v1/orgs/$OWNER") == 200 ]]; then
  OTYPE=org; ok "owner '$OWNER' is an organization"
  c=$(code "$URL/api/v1/orgs/$OWNER/members/$LOGIN")
  [[ $c == 204 ]] && ok "$LOGIN is a member of $OWNER" \
    || warn "$LOGIN is not a (visible) member of org $OWNER (HTTP $c). Pushing needs a team in $OWNER with write access to Packages and Code."
  # packages write is granted per team; check the user's teams in this org
  if [[ $(code "$URL/api/v1/user/teams?limit=200") == 200 ]]; then
    # one team per line, keep only teams of this org
    sed 's/^\[//; s/},{"id":/}\n{"id":/g' "$TMP/resp" | grep -i "\"organization\":{[^}]*\"username\":\"$OWNER\"" > "$TMP/teams" || true
    if [[ ! -s "$TMP/teams" ]]; then
      warn "you are in no team of $OWNER. Ask an org owner to add you to a team with Packages: Write and Code: Write."
    elif grep -Eq '"repo.packages":"(write|admin)"|"permission":"(write|owner|admin)"' "$TMP/teams"; then
      ok "your team in $OWNER has write on packages ($(sed -n 's/^{"id":[0-9]*,"name":"\([^"]*\)".*/\1/p' "$TMP/teams" | paste -sd, -))"
    else
      warn "your teams in $OWNER don't show Packages: Write. Pushes may get 401/403. Ask an org owner (Org > Teams > Packages: Write)."
    fi
  fi
elif [[ $(code "$URL/api/v1/users/$OWNER") == 200 ]]; then
  OTYPE=user
  [[ "${OWNER,,}" == "${LOGIN,,}" ]] || die "'$OWNER' is another user. You can only publish to your own user or to an org where your team has write access. If your repos live under an organization, pass --owner <org>."
  ok "owner '$OWNER' is your user"
else
  die "owner '$OWNER' not found as an organization or user. Check the exact org name in Gitea (Explore > Organizations); repos are often under an org."
fi

if ((DO_GIT || DO_LINK)); then
  c=$(code "$URL/api/v1/repos/$OWNER/$REPO")
  if [[ $c == 200 ]]; then ok "repo $OWNER/$REPO exists"
  elif [[ $c == 404 ]] && ((CREATE)); then
    ep="$URL/api/v1/user/repos"; [[ $OTYPE == org ]] && ep="$URL/api/v1/orgs/$OWNER/repos"
    if ! dry "create private repo $OWNER/$REPO"; then
      c=$(code -X POST -H 'Content-Type: application/json' "$ep" \
          -d "{\"name\":\"$REPO\",\"private\":true,\"auto_init\":true,\"default_branch\":\"$BRANCH\",\"description\":\"air-gap bundles\"}")
      if [[ $c != 201 ]]; then
        msg="$(head -c 300 "$TMP/resp")"
        hint="Ask an org owner to create $OWNER/$REPO, then re-run without --create-repo."
        [[ "$msg" == *write:organization* ]] && hint="Creating a repo in an org needs a token with the write:organization scope. $hint"
        [[ "$msg" == *"not allowed to create repositories"* ]] && hint="Your team in $OWNER lacks 'Create repositories' (Org > Teams > Edit). $hint"
        die "could not create $OWNER/$REPO (HTTP $c): $msg
      $hint"
      fi
      ok "created private repo $OWNER/$REPO"
    fi
  elif [[ $c == 404 ]]; then die "repo $OWNER/$REPO not found. Create it in Gitea, or re-run with --create-repo"
  else die "cannot read repo $OWNER/$REPO (HTTP $c)"; fi
fi

PUBLISHED="$TMP/PUBLISHED.md"
{ echo "# Published to Gitea"; echo; echo "- bundle: $BNAME"; echo "- gitea: $URL, owner: $OWNER ($OTYPE), repo: $OWNER/$REPO"; echo "- by: $LOGIN"; echo; } > "$PUBLISHED"
LINKS=()   # "type<TAB>name"

# ---------------------------------------------------------------- charts
if ((DO_CHART)) && compgen -G "$BUNDLE/payload/charts/*.tgz" >/dev/null; then
  step "helm charts -> $URL/api/packages/$OWNER/helm"
  echo "## Helm charts" >> "$PUBLISHED"
  for f in "$BUNDLE"/payload/charts/*.tgz; do
    top="$(tar -tzf "$f" | head -1 | cut -d/ -f1)"
    cname="$(tar -xzOf "$f" "$top/Chart.yaml" | sed -n 's/^name:[[:space:]]*//p' | tr -d "\"'" | head -1)"
    cver="$(tar -xzOf "$f" "$top/Chart.yaml" | sed -n 's/^version:[[:space:]]*//p' | tr -d "\"'" | head -1)"
    if ! dry "upload chart $cname $cver"; then
      c=$(code -X POST --upload-file "$f" "$URL/api/packages/$OWNER/helm/api/charts")
      case $c in 201) ok "chart $cname $cver uploaded";; 409) ok "chart $cname $cver already there";;
                 *) die "chart $cname upload HTTP $c: $(head -c 300 "$TMP/resp")";; esac
    fi
    echo "- $cname $cver" >> "$PUBLISHED"; LINKS+=("helm	$cname")
  done
  { echo; echo '```bash'; echo "helm repo add $OWNER_LC $URL/api/packages/$OWNER/helm --username <user> --password <token>"; echo "helm repo update"; echo '```'; echo; } >> "$PUBLISHED"
fi

# ---------------------------------------------------------------- images
norm() {  # upstream ref -> "path<TAB>tag"  (registry host dropped, docker.io/library/ kept as library/)
  local r="$1" first rest tag
  first="${r%%/*}"
  if [[ "$r" == */* && ( "$first" == *.* || "$first" == *:* || "$first" == localhost ) ]]; then rest="${r#*/}"; else rest="$r"; fi
  [[ "$rest" == */* ]] || rest="library/$rest"
  if [[ "$rest" == *@sha256:* ]]; then tag="sha256-${rest##*@sha256:}"; tag="${tag:0:19}"; rest="${rest%@*}"
  elif [[ "${rest##*/}" == *:* ]]; then tag="${rest##*:}"; rest="${rest%:*}"
  else tag=latest; fi
  printf '%s\t%s\n' "$(printf '%s' "$rest" | tr '[:upper:]' '[:lower:]')" "$tag"
}
if ((DO_IMG)) && compgen -G "$BUNDLE/payload/images/*.tar" >/dev/null; then
  if [[ -z "$TOOL" ]]; then for t in skopeo crane docker; do command -v $t >/dev/null && { TOOL=$t; break; }; done; fi
  [[ -n "$TOOL" ]] || die "need skopeo, crane or docker to push images (bundle a static crane in payload/bin)"
  step "images -> $REGISTRY/$OWNER_LC/... (using $TOOL)"
  if ! dry "login to $REGISTRY as $LOGIN"; then
    case $TOOL in
      docker) printf '%s' "$GITEA_TOKEN" | docker login "$REGISTRY" -u "$LOGIN" --password-stdin >/dev/null 2>&1 || die "docker login to $REGISTRY failed" ;;
      crane)  crane auth login "$REGISTRY" -u "$LOGIN" -p "$GITEA_TOKEN" >/dev/null ;;
      skopeo) : ;;   # creds passed per copy
    esac
  fi
  echo "## Container images" >> "$PUBLISHED"; echo >> "$PUBLISHED"
  echo "| upstream | in Gitea |" >> "$PUBLISHED"; echo "|---|---|" >> "$PUBLISHED"
  for f in "$BUNDLE"/payload/images/*.tar; do
    b="$(basename "$f")"; ref=""
    [[ -f "$BUNDLE/payload/images/images.tsv" ]] && ref="$(awk -F'\t' -v f="$b" '$3==f{print $1; exit}' "$BUNDLE/payload/images/images.tsv")"
    [[ -n "$ref" ]] || ref="$(tar -xOf "$f" manifest.json 2>/dev/null | grep -o '"RepoTags":\["[^"]*"' | head -1 | sed 's/.*\["//; s/"$//')"
    [[ -n "$ref" ]] || { warn "$b: can't tell which image this is (no images.tsv entry, no RepoTags). Skipped."; continue; }
    IFS=$'\t' read -r ipath itag < <(norm "$ref")
    dest="$REGISTRY/$OWNER_LC/$ipath:$itag"
    if ! dry "push $ref -> $dest"; then
      case $TOOL in
        skopeo) st=(); [[ -n "$CA" ]] && st=(--dest-cert-dir "$(dirname "$CA")"); ((INSECURE)) && st=(--dest-tls-verify=false)
                [[ "$REGISTRY" == localhost* || "$REGISTRY" == 127.* ]] && st=(--dest-tls-verify=false)
                skopeo copy -q "${st[@]}" --dest-creds "$LOGIN:$GITEA_TOKEN" "docker-archive:$f" "docker://$dest" ;;
        crane)  ci=(); ((INSECURE)) && ci=(--insecure); crane push "${ci[@]}" "$f" "$dest" >/dev/null ;;
        docker) loaded="$(docker load -i "$f" | sed -n 's/^Loaded image: //p; s/^Loaded image ID: //p' | head -1)"
                [[ -n "$loaded" ]] || die "docker load $b gave no image"
                docker tag "$loaded" "$dest" && docker push -q "$dest" >/dev/null && docker rmi "$dest" >/dev/null ;;
      esac || die "push failed: $dest"
      ok "$ref -> $dest"
    fi
    echo "| \`$ref\` | \`$dest\` |" >> "$PUBLISHED"; LINKS+=("container	$ipath")
  done
  cat >> "$PUBLISHED" <<EOF

k3s nodes can pull these with the upstream names unchanged. Add a mirror with a rewrite to
\`/etc/rancher/k3s/registries.yaml\` on every node (back up and merge with the existing file), then restart k3s:

\`\`\`yaml
mirrors:
  docker.io:
    endpoint: ["$URL"]
    rewrite:
      "^(.*)\$": "$OWNER_LC/\$1"
  # repeat for quay.io, ghcr.io, registry.k8s.io ... if the bundle has images from them
configs:
  "$REGISTRY":
    auth: {username: <user>, password: <read:package token>}   # needed unless the org is public
    # tls: {ca_file: /etc/rancher/k3s/gitea-ca.crt}
\`\`\`
EOF
fi

# ---------------------------------------------------------------- generic files
if ((GENERIC)); then
  gname="$(printf '%s' "$BNAME" | tr -c 'A-Za-z0-9.+_\n-' '_')"; gver=1
  step "generic files -> $URL/api/packages/$OWNER/generic/$gname/$gver"
  { echo; echo "## Generic files (package $gname, version $gver)"; } >> "$PUBLISHED"
  while IFS= read -r -d '' f; do
    rel="${f#"$BUNDLE"/payload/}"; fn="$(printf '%s' "$rel" | tr '/' '_' | tr -c 'A-Za-z0-9.+_\n-' '_')"
    if ! dry "upload $rel as $fn"; then
      c=$(code --upload-file "$f" "$URL/api/packages/$OWNER/generic/$gname/$gver/$fn")
      case $c in 201) ok "$rel";; 409) ok "$rel already there";; *) die "$rel upload HTTP $c: $(head -c 300 "$TMP/resp")";; esac
    fi
    echo "- \`$fn\` (from payload/$rel)" >> "$PUBLISHED"
  done < <(find "$BUNDLE/payload" -mindepth 2 -type f ! -path '*/payload/images/*' ! -path '*/payload/charts/*' -print0 | sort -z)
  LINKS+=("generic	$gname")
fi

# ---------------------------------------------------------------- git: values, scripts, docs
if ((DO_GIT)); then
  step "git -> $OWNER/$REPO:$BRANCH/$RPATH"
  auth="Authorization: Basic $(printf '%s:%s' "$LOGIN" "$GITEA_TOKEN" | base64 | tr -d '\n')"
  G=(git "${GIT_TLS[@]}" -c "http.extraHeader=$auth")
  if ! dry "commit repo/ + MANIFEST/README/checksums + PUBLISHED.md into $RPATH and push"; then
    "${G[@]}" clone -q "$URL/$OWNER/$REPO.git" "$TMP/clone" 2>&1 | grep -v 'empty repository' || true
    cd "$TMP/clone"
    git rev-parse -q --verify HEAD >/dev/null && { git checkout -q "$BRANCH" 2>/dev/null || git checkout -q -b "$BRANCH"; } || git checkout -q -b "$BRANCH"
    rm -rf "./$RPATH"; mkdir -p "./$RPATH"
    cp -a "$BUNDLE/repo/." "./$RPATH/"
    for x in MANIFEST.yaml README.md checksums.sha256; do [[ -f "$BUNDLE/$x" ]] && cp "$BUNDLE/$x" "./$RPATH/"; done
    cp "$PUBLISHED" "./$RPATH/PUBLISHED.md"
    git add -A
    if git diff --cached --quiet; then ok "nothing changed in $RPATH"
    else
      git -c user.name="$LOGIN" -c user.email="$LOGIN@noreply.invalid" commit -q -m "airgap bundle: $BNAME"
      "${G[@]}" push -q origin "HEAD:$BRANCH"
      ok "pushed $RPATH ($(git rev-parse --short HEAD))"
    fi
    cd - >/dev/null
  fi
fi

# ---------------------------------------------------------------- link packages to the repo
if ((DO_LINK)) && ((${#LINKS[@]})); then
  step "link packages to $OWNER/$REPO"
  printf '%s\n' "${LINKS[@]}" | sort -u | while IFS=$'\t' read -r t n; do
    en="$(printf '%s' "$n" | sed 's#/#%2F#g')"
    dry "link $t/$n" && continue
    c=$(code -X POST "$URL/api/v1/packages/$OWNER/$t/$en/-/link/$REPO")
    if [[ $c == 400 ]]; then   # 400 = already linked (or not linkable): check what it is linked to now
      code "$URL/api/v1/packages/$OWNER?type=$t&q=$en" >/dev/null
      if sed 's/^\[//; s/},{"id":/}\n{"id":/g' "$TMP/resp" | grep -i "\"name\":\"$n\"" | grep -qi "\"full_name\":\"$OWNER/$REPO\""; then
        ok "$t/$n already linked"; continue; fi
    fi
    case $c in 201|204) ok "linked $t/$n";; 404) warn "link $t/$n: endpoint or package not found (older Gitea?). Link it in the UI: package > Settings.";;
               *) warn "link $t/$n HTTP $c: $(head -c 200 "$TMP/resp")";; esac
  done
fi

step "done"
echo "Repo:     $URL/$OWNER/$REPO/src/branch/$BRANCH/$RPATH"
echo "Packages: $URL/$OWNER/-/packages"
((DRY)) && echo "(dry run: nothing was changed)"
exit 0
