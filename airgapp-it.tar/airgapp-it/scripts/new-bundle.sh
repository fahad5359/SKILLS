#!/usr/bin/env bash
# Create an airgapp-it bundle skeleton.
# Usage: new-bundle.sh <name> [version]   -> prints the bundle path
# Pre-fills repo/site.env from ~/airgap/target-profile.yaml (simple "key: value" lookups) when present.
set -euo pipefail
name="${1:?usage: new-bundle.sh <name> [version]}"
version="${2:-0.0.0}"
home="${AIRGAP_HOME:-$HOME/airgap}"
root="$home/bundles"
dir="$root/${name}-${version}-$(date +%Y%m%d)"
skill="$(cd "$(dirname "$0")" && pwd)"
if [[ -e "$dir" ]]; then echo "exists: $dir" >&2; echo "$dir"; exit 0; fi

mkdir -p "$dir"/repo/config "$dir"/payload/{images,charts,wheels,bin,pkgs,models,src}

# --- profile lookups (best effort, no yaml parser needed) ---
prof="$home/target-profile.yaml"
pget() {  # pget <key> <default>: first "key: value" in the profile, also matches inline maps "{key: value}"
  local v=""
  [[ -f "$prof" ]] && v="$(grep -oE "(^|[ {,])$1:[[:space:]]*[^,}#]+" "$prof" | head -1 | sed -E "s/.*$1:[[:space:]]*//; s/[[:space:]]+$//; s/^[\"']//; s/[\"']$//")" || true
  printf '%s' "${v:-$2}"
}
gurl="$(pget url "")"; ghost="${gurl#*://}"; ghost="${ghost%%/*}"
arch_here="$(uname -m | sed 's/x86_64/amd64/; s/aarch64/arm64/')"

cat > "$dir/repo/site.env" <<ENV
# site.env: the ONLY file to edit on the air-gapped side.
# install.sh refuses to run while a key in REQUIRED_KEYS is still CHANGE_ME.
# Other CHANGE_ME keys only matter if you use that feature.

# --- built for (informational, don't change) ---
TARGET_ARCH=$(pget arch "$arch_here")

# --- how images reach k3s ---
# import   = install.sh loads payload/images/*.tar into k3s on this node (repeat on every node)
# registry = pull from a registry (e.g. Gitea, after publish-to-gitea.sh)
IMAGE_MODE=$(pget image_mode import)
REGISTRY_HOST=$(pget registry_host "${ghost:-CHANGE_ME}")          # only for IMAGE_MODE=registry

# --- Gitea (for publish-to-gitea.sh) ---
GITEA_URL=$(pget url CHANGE_ME)                        # e.g. https://git.example.lan
GITEA_OWNER=$(pget owner CHANGE_ME)                    # usually an ORGANIZATION, not your username
GITEA_REPO=$(pget repo airgap-bundles)

# --- k3s ---
STORAGE_CLASS=$(pget storage_class local-path)
INGRESS_CLASS=$(pget ingress traefik)

# --- app-specific (the agent adds keys below) ---

# keys install.sh must not run without (space separated)
REQUIRED_KEYS=""
ENV

cat > "$dir/MANIFEST.yaml" <<YAML
bundle: $(basename "$dir")
created: $(date +%F)
thing: "TODO: what is being airgapped (copied from the working setup here)"
target: {arch: $(pget arch "$arch_here")}
assumptions: []       # defaults picked instead of asking, one line each
prerequisites: []
artifacts: []
left_out: []
site_values: []       # site.env keys the user must fill over there
YAML

b="$(basename "$dir")"
cat > "$dir/README.md" <<MD
# $b

TODO: one line on what this installs.

## 1. Check the transfer and unpack
\`\`\`bash
sha256sum -c $b.parts.sha256
cat $b.tar.*.part* | zstd -d | tar -xf -      # .tar.gz parts: use gzip -d
cd $b && sha256sum -c checksums.sha256
\`\`\`

## 2. Fill in site values
Edit \`repo/site.env\`. install.sh lists any required key that is still CHANGE_ME.

## 3. Prerequisites on the air-gapped side
- TODO

## 4. Install
\`\`\`bash
./repo/install.sh
\`\`\`

## 5. Verify
\`\`\`bash
./repo/verify.sh
\`\`\`
If anything prints FAIL, paste the whole output back to Claude.

## 6. Roll back
\`\`\`bash
./repo/uninstall.sh
\`\`\`
MD

for s in install verify uninstall; do
cat > "$dir/repo/$s.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD_DIR="${PAYLOAD_DIR:-$HERE/../payload}"   # override if payload lives elsewhere (e.g. after git clone)
# shellcheck source=/dev/null
. "$HERE/site.env"
pass() { printf 'PASS  %s\n' "$*"; }
fail() { printf 'FAIL  %s\n' "$*"; FAILED=1; }
FAILED=0
missing=""
for k in $REQUIRED_KEYS; do if [[ -z "${!k:-}" || "${!k}" == CHANGE_ME ]]; then missing="$missing $k"; fi; done
if [[ $IMAGE_MODE == registry && $REGISTRY_HOST == CHANGE_ME ]]; then missing="$missing REGISTRY_HOST"; fi
if [[ -n "$missing" ]]; then echo "Fill these in $HERE/site.env first:$missing" >&2; exit 1; fi
# TODO: fill in
SH
echo "exit \$FAILED" >> "$dir/repo/$s.sh"
chmod +x "$dir/repo/$s.sh"
done

cp "$skill/publish-to-gitea.sh" "$dir/repo/publish-to-gitea.sh"
echo "$dir"
