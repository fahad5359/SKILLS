#!/usr/bin/env bash
# List container images a Helm chart (or a live namespace) uses.
# Usage:
#   helm-images.sh <chart(.tgz|dir|repo/chart)> [helm template args...]   e.g. -f values.yaml -n ns --version 1.2.3
#   helm-images.sh --live <namespace>      images actually running (incl. operator-spawned), with digests
# Output: sorted unique image refs on stdout; heuristics/warnings on stderr.
set -euo pipefail
if [[ "${1:-}" == "--live" ]]; then
  ns="${2:?namespace}"
  kubectl get pods -n "$ns" -o jsonpath='{range .items[*]}{range .status.initContainerStatuses[*]}{.image}{"\t"}{.imageID}{"\n"}{end}{range .status.containerStatuses[*]}{.image}{"\t"}{.imageID}{"\n"}{end}{end}' \
    | sort -u
  exit 0
fi
chart="${1:?usage: helm-images.sh <chart> [helm template args...] | --live <ns>}"; shift
tmp="$(mktemp)"; trap 'rm -f "$tmp"' EXIT
rendered="$(helm template airgap-probe "$chart" "$@")"

# 1) explicit image: fields (YAML and JSON styles)
printf '%s\n' "$rendered" \
  | grep -E '^[[:space:]-]*"?image"?[[:space:]]*:' \
  | sed -E 's/^[^:]*:[[:space:]]*//; s/["'\'']//g; s/[[:space:]]+#.*$//; s/,$//; s/[[:space:]]*$//' \
  | grep -vE '^$|^\{|^null$' | sort -u > "$tmp" || true
cat "$tmp"

# 2) heuristic: image-looking strings elsewhere (args, env, configmaps) not already found
printf '%s\n' "$rendered" \
  | grep -oE '([a-z0-9-]+\.)+[a-z]{2,}(:[0-9]+)?/[a-z0-9._/-]+(:[A-Za-z0-9._-]+|@sha256:[a-f0-9]{64})' \
  | grep -vE '^(https?|[a-z0-9.-]+\.svc)' | sort -u \
  | grep -vxF -f "$tmp" \
  | sed 's/^/POSSIBLE (check by hand): /' >&2 || true

n=$(wc -l < "$tmp")
echo "-- $n image field(s). Also run with --live <ns> to catch operator-spawned images." >&2
