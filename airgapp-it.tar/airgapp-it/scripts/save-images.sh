#!/usr/bin/env bash
# Pull images for a target platform and save each as a k3s/containerd-importable tar.
# Usage: save-images.sh <out-dir> <images.txt | image...> [--platform linux/amd64]
#   images.txt: one ref per line, '#' comments allowed.
# Writes <out-dir>/<sanitized>.tar and appends "ref<TAB>digest<TAB>file<TAB>platform" to <out-dir>/images.tsv
# Tool preference: skopeo > crane > docker.
set -euo pipefail
out="${1:?usage: save-images.sh <out-dir> <images.txt|image...> [--platform os/arch]}"; shift
platform="linux/amd64"; refs=()
while (($#)); do
  case "$1" in
    --platform) platform="$2"; shift 2;;
    *) if [[ -f "$1" ]]; then mapfile -t -O "${#refs[@]}" refs < <(sed 's/#.*//; s/[[:space:]]//g; /^$/d' "$1"); else refs+=("$1"); fi; shift;;
  esac
done
((${#refs[@]})) || { echo "no images given" >&2; exit 1; }
mkdir -p "$out"; arch="${platform#*/}"; os="${platform%%/*}"

tool=docker
command -v crane  >/dev/null && tool=crane
command -v skopeo >/dev/null && tool=skopeo
echo "using $tool, platform $platform, ${#refs[@]} image(s)" >&2

rc=0
for ref in "${refs[@]}"; do
  full="$ref"; first="${ref%%/*}"
  [[ "$ref" == */* ]] || full="docker.io/library/$ref"
  [[ "$ref" == */* && "$first" != *.* && "$first" != *:* && "$first" != localhost ]] && full="docker.io/$ref"
  [[ "${full##*/}" == *[:@]* ]] || echo "    WARNING: $ref has no tag/digest (= latest). Pin it." >&2
  [[ "$full" == *:latest ]] && echo "    WARNING: $ref uses :latest. Pin it." >&2
  f="$(printf '%s' "$full" | sed 's#[/:@]#_#g').tar"
  echo "==> $ref" >&2
  if [[ -s "$out/$f" ]]; then echo "    exists, skipping" >&2; continue; fi
  digest=""
  case $tool in
    skopeo)
      skopeo copy --override-os "$os" --override-arch "$arch" "docker://$ref" "docker-archive:$out/$f:$ref" >&2 \
        && digest="$(skopeo inspect --override-os "$os" --override-arch "$arch" "docker://$ref" --format '{{.Digest}}')" || rc=1;;
    crane)
      crane pull --platform "$platform" "$ref" "$out/$f" >&2 \
        && digest="$(crane digest --platform "$platform" "$ref")" || rc=1;;
    docker)
      # keep the user's local docker untouched: remember what the tag pointed to before
      old="$(docker image inspect -f '{{.Id}}' "$ref" 2>/dev/null || true)"
      if pout="$(docker pull --platform "$platform" "$ref" 2>&1)"; then
        printf '%s\n' "$pout" | grep -E '^(Digest|Status):' | sed 's/^/    /' >&2
        if docker save --help 2>/dev/null | grep -q -- '--platform'; then
          docker save --platform "$platform" -o "$out/$f" "$ref" || rc=1
        else
          docker save -o "$out/$f" "$ref" || rc=1
        fi
        digest="$(printf '%s\n' "$pout" | sed -n 's/^Digest: //p' | head -1)"
        got="$(docker image inspect --format '{{.Os}}/{{.Architecture}}' "$ref" 2>/dev/null || true)"
        [[ -z "$got" || "$got" == "$platform" ]] || echo "    WARNING: local image is $got, wanted $platform" >&2
        new="$(docker image inspect -f '{{.Id}}' "$ref" 2>/dev/null || true)"
        if [[ -n "$old" && "$old" != "$new" ]]; then docker tag "$old" "$ref"          # restore previous tag
        elif [[ -z "$old" ]]; then docker rmi "$ref" >/dev/null 2>&1 || true; fi        # wasn't here before
      else printf '%s\n' "$pout" | tail -3 >&2; rc=1; fi;;
  esac
  if [[ -s "$out/$f" ]]; then
    printf '%s\t%s\t%s\t%s\n' "$ref" "${digest:-unknown}" "$f" "$platform" >> "$out/images.tsv"
    echo "    saved $f ($(du -h "$out/$f" | cut -f1)) digest ${digest:-unknown}" >&2
  else
    echo "    FAILED $ref" >&2; rm -f "$out/$f"; rc=1
  fi
done
exit $rc
