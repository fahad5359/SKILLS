#!/usr/bin/env bash
# Checksum, size-report, secret-scan and pack a bundle.
# Usage: finalize.sh <bundle-dir> [--split 4G] [--no-pack]
set -euo pipefail
b="$(cd "${1:?usage: finalize.sh <bundle-dir> [--split SIZE] [--no-pack]}" && pwd)"; shift
split=""; pack=1
while (($#)); do case "$1" in --split) split="$2"; shift 2;; --no-pack) pack=0; shift;; *) echo "unknown arg $1" >&2; exit 1;; esac; done
name="$(basename "$b")"; parent="$(dirname "$b")"

echo "== secret scan (warnings only) =="
grep -rIlE -i '(BEGIN [A-Z ]*PRIVATE KEY|password[[:space:]]*[:=][[:space:]]*[^[:space:]<{$]|token[[:space:]]*[:=][[:space:]]*[A-Za-z0-9_.-]{16,}|AKIA[0-9A-Z]{16})' \
  "$b/repo" "$b/MANIFEST.yaml" 2>/dev/null | sed 's/^/  CHECK: /' || echo "  nothing obvious"

echo "== checksums =="
( cd "$b" && find repo payload MANIFEST.yaml README.md -type f ! -name checksums.sha256 -print0 2>/dev/null \
    | sort -z | xargs -0 -r sha256sum > checksums.sha256 )
echo "  $(wc -l < "$b/checksums.sha256") files -> $b/checksums.sha256"

echo "== sizes =="
du -sh "$b"/repo "$b"/payload/* 2>/dev/null | awk '$1!="0" && $1!="4.0K"' | sed "s#$b/#  #"
du -sh "$b" | sed "s#$b#  TOTAL#"

((pack)) || exit 0
echo "== pack =="
if command -v zstd >/dev/null; then ext=tar.zst; comp=(zstd -T0 -10 -q); dec="zstd -d"
else ext=tar.gz; comp=(gzip -6); dec="gzip -d"; fi
cd "$parent"
rm -f "$name.$ext" "$name.$ext".part* "$name.parts.sha256"
if [[ -n "$split" ]]; then
  tar -cf - "$name" | "${comp[@]}" | split -b "$split" -d -a 3 - "$name.$ext.part"
else
  tar -cf - "$name" | "${comp[@]}" > "$name.$ext"
fi
sha256sum "$name.$ext"* > "$name.parts.sha256"
ls -lh "$name.$ext"* "$name.parts.sha256" | awk '{print "  "$5"  "$9}'
echo
echo "On the other side:"
echo "  sha256sum -c $name.parts.sha256"
if [[ -n "$split" ]]; then
  echo "  cat $name.$ext.part* | $dec | tar -xf -"
else
  echo "  tar -xf $name.$ext"
fi
echo "  cd $name && sha256sum -c checksums.sha256"
