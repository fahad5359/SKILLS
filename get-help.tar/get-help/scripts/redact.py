#!/usr/bin/env python3
"""
redact.py - deterministic redaction pass for the get-help skill.

Replaces private data with the literal token <redacted>.
Standard library only (Python 3.8+), no network access, works on Linux/macOS/Windows.

Usage:
  redact.py redact INPUT [-o OUTPUT] [--report REPORT]   # write a redacted copy
  redact.py check  INPUT [--report REPORT]               # exit 1 if anything private is left

INPUT can be "-" for stdin.
Options (both commands):
  --terms FILE   company terms list   (default: <skill>/config/private-terms.txt)
  --allow FILE   public allowlist     (default: <skill>/config/public-allowlist.txt)
  --keep TEXT    exact text you checked and know is public (repeatable), e.g. --keep "1.2.3.4"
"""
import argparse
import ipaddress
import math
import re
import sys
from collections import OrderedDict
from pathlib import Path

TOKEN = "<redacted>"
S = "\x00R\x00"  # internal marker while processing, turned into TOKEN at the end

SKILL_DIR = Path(__file__).resolve().parent.parent
DEFAULT_TERMS = SKILL_DIR / "config" / "private-terms.txt"
DEFAULT_ALLOW = SKILL_DIR / "config" / "public-allowlist.txt"

# Top-level domains that only exist inside companies.
INTERNAL_TLDS = {
    "local", "lan", "internal", "intra", "intranet", "corp", "home", "localdomain",
    "ad", "priv", "private", "int", "domain", "office", "loc", "grp", "infra",
}
# Real public TLDs we treat as "this is a hostname".
PUBLIC_TLDS = {
    "com", "net", "org", "edu", "gov", "mil", "biz", "info", "io", "co", "ai", "app",
    "dev", "cloud", "tech", "online", "site", "xyz", "me", "us", "uk", "de", "fr", "nl",
    "il", "eu", "ca", "au", "in", "jp", "cn", "ru", "br", "es", "it", "ch", "se", "no",
    "dk", "fi", "pl", "at", "be", "cz", "ie", "nz", "za", "sg", "hk", "kr", "tw", "mx",
    "ar", "tr", "gr", "pt", "ro", "hu", "ua", "sk", "bg", "hr", "si", "lt", "lv", "ee",
    "is", "lu", "ae", "sa", "qa", "eg", "ma", "ng", "ke", "ph", "my", "th", "vn", "id",
    "pk", "bd", "cl", "pe", "uy", "ve", "global", "group", "solutions", "services",
    "systems", "network", "digital", "company", "corporate", "enterprises", "bank",
    "finance", "health", "aws", "azure", "gcp", "name", "run", "page", "link", "zip",
    "mov", "top", "tv", "ms", "ws", "cc", "to", "do", "as", "by", "am", "mk", "ml",
    "sh", "py", "md", "rs", "so", "ps", "cs", "sc",
}
# Public TLDs that collide with file extensions and code (user.id, self.app, main.py).
# A two-label name with one of these is NOT auto-redacted; it is reported as
# "possible hostname" so the agent reviews it by hand.
AMBIGUOUS_TLDS = {
    "py", "sh", "md", "rs", "pl", "so", "ps", "cc", "cs", "ml", "mk", "am", "sc",
    "in", "is", "it", "id", "to", "me", "my", "no", "do", "at", "as", "by", "name",
    "app", "info", "run", "page", "link", "zip", "mov", "top", "dev", "ai", "tv",
    "ms", "ws", "co", "ch", "de", "es", "se", "be",
}
REGISTRY_KEYS = {"HKLM", "HKCU", "HKCR", "HKU", "HKCC", "HKEY_LOCAL_MACHINE", "HKEY_CURRENT_USER"}


# --------------------------------------------------------------------------- config

def load_lines(path):
    p = Path(path)
    if not p.is_file():
        return None
    out = []
    for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if line and not line.startswith("#"):
            out.append(line)
    return out


class Allow:
    def __init__(self, lines):
        self.domains = set()      # keep domain and all its subdomains
        self.suffixes = []        # ".svc.cluster.local" -> keep suffix, redact the rest
        self.emails = set()
        self.ips = set()
        self.nets = []
        for line in lines or []:
            l = line.lower()
            if "@" in l:
                self.emails.add(l)
            elif l.startswith("."):
                self.suffixes.append(l)
            else:
                try:
                    if "/" in l:
                        self.nets.append(ipaddress.ip_network(l, strict=False))
                    else:
                        self.ips.add(ipaddress.ip_address(l))
                    continue
                except ValueError:
                    self.domains.add(l)
        self.suffixes.sort(key=len, reverse=True)

    def domain_kept(self, name):
        n = name.lower().rstrip(".")
        return any(n == d or n.endswith("." + d) for d in self.domains)

    def domain_suffix(self, name):
        n = name.lower()
        for s in self.suffixes:
            if n.endswith(s) and len(n) > len(s):
                return name[len(name) - len(s):]
        return None

    def ip_kept(self, ip):
        if ip in self.ips:
            return True
        return any(ip.version == n.version and ip in n for n in self.nets)


def build_term_patterns(lines):
    pats = []
    for line in sorted(lines or [], key=len, reverse=True):
        try:
            if line.startswith("re:"):
                pats.append((line, re.compile(line[3:], re.IGNORECASE)))
                continue
            whole = False
            term = line
            if line.startswith("word:"):
                whole, term = True, line[5:].strip()
            if not term:
                continue
            if len(term) < 4:
                whole = True
            # "acme corp" also matches acme-corp, acme_corp, acmecorp
            parts = [re.escape(p) for p in re.split(r"[\s_-]+", term) if p]
            body = r"[\s_-]?".join(parts)
            if whole:
                body = r"(?<![A-Za-z0-9])" + body + r"(?![A-Za-z0-9])"
            pats.append((line, re.compile(body, re.IGNORECASE)))
        except re.error as e:
            print(f"warning: bad pattern in terms file: {line!r} ({e})", file=sys.stderr)
    return pats


# --------------------------------------------------------------------------- engine

class Redactor:
    def __init__(self, terms, allow, check=False, keep=()):
        self.check = check
        self.keep = sorted({k for k in keep if k}, key=len, reverse=True)
        self.terms = build_term_patterns(terms)
        self.allow = Allow(allow)
        self.found = OrderedDict()   # (category, value) -> count
        self.review = OrderedDict()  # possible hostnames for manual review

    def hit(self, cat, value):
        key = (cat, value.strip())
        self.found[key] = self.found.get(key, 0) + 1

    def sub(self, text, cat, pattern, repl=None, flags=0):
        rx = re.compile(pattern, flags) if isinstance(pattern, str) else pattern

        def _r(m):
            if repl is None:
                if S in m.group(0):
                    return m.group(0)
                self.hit(cat, m.group(0))
                return S
            return repl(m)
        return rx.sub(_r, text)

    # ---- rules -----------------------------------------------------------

    def r_pem(self, t):
        rx = re.compile(r"(-----BEGIN ([A-Z0-9 ]+)-----)(.*?)(-----END \2-----)", re.S)

        def _r(m):
            self.hit("pem-block", m.group(1))
            return f"{m.group(1)}\n{S}\n{m.group(4)}"
        return rx.sub(_r, t)

    def r_known_tokens(self, t):
        pats = [
            r"\b(?:AKIA|ASIA|AGPA|AIDA|AROA)[0-9A-Z]{16}\b",
            r"\bgh[pousr]_[A-Za-z0-9]{20,}\b", r"\bgithub_pat_[A-Za-z0-9_]{20,}\b",
            r"\bglpat-[A-Za-z0-9_-]{20,}\b", r"\bxox[abposr]-[A-Za-z0-9-]{10,}\b",
            r"\bsk-[A-Za-z0-9_-]{20,}\b", r"\bAIza[0-9A-Za-z_-]{35}\b",
            r"\bnpm_[A-Za-z0-9]{30,}\b", r"\bhf_[A-Za-z0-9]{30,}\b",
            r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b",  # JWT
        ]
        for p in pats:
            t = self.sub(t, "token", p)
        return t

    def r_auth_header(self, t):
        rx = re.compile(r"(?i)(authorization\s*[:=]\s*[\"']?(?:bearer|basic|token|negotiate|digest)\s+)([^\s\"']+)")

        def _r(m):
            if m.group(2) == S:
                return m.group(0)
            self.hit("auth-header", m.group(2))
            return m.group(1) + S
        return rx.sub(_r, t)

    def r_url_creds(self, t):
        rx = re.compile(r"([A-Za-z][A-Za-z0-9+.-]*://)([^/\s:@]+):([^/\s]+)@(?=[^@/\s]*(?:[/\s?#]|$))")

        def _r(m):
            if m.group(2) == S and m.group(3) == S:
                return m.group(0)
            self.hit("url-credentials", m.group(2) + ":" + m.group(3))
            return f"{m.group(1)}{S}:{S}@"
        return rx.sub(_r, t)

    def r_kv_secrets(self, t):
        keys = (r"password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|"
                r"client[_-]?secret|credentials?|conn(?:ection)?[_-]?string|sas[_-]?key|"
                r"shared[_-]?key|account[_-]?key|bind[_-]?pw")
        rx = re.compile(r"(?i)((?<![A-Za-z0-9])[\w.-]*(?:" + keys + r")[\w.-]*[\"']?\s*[:=]\s*[\"']?)([^\s\"',;]+)")

        def _r(m):
            v = m.group(2)
            if S in v or v.lower() in {"true", "false", "null", "none", "''", '""'}:
                return m.group(0)
            self.hit("secret-value", m.group(0))
            return m.group(1) + S
        return rx.sub(_r, t)

    def r_arn(self, t):
        rx = re.compile(r"arn:(aws[\w-]*):([\w-]*):([\w-]*):(\d{12})?:([^\s\"',]+)")

        def _r(m):
            self.hit("arn", m.group(0))
            acct = S if m.group(4) else ""
            return f"arn:{m.group(1)}:{m.group(2)}:{m.group(3)}:{acct}:{S}"
        return rx.sub(_r, t)

    def r_email(self, t):
        rx = re.compile(r"(?<![\w.+-])[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?![\w-])")

        def _r(m):
            if m.group(0).lower() in self.allow.emails:
                return m.group(0)
            self.hit("email", m.group(0))
            return S
        return rx.sub(_r, t)

    def r_ldap_dn(self, t):
        key = r"(?:CN|OU|DC|O|L|ST|C|UID)="
        mid = key + r"[^,\n\"=]+"
        last = key + r"[^,\n\"=\s]+"
        rx = re.compile(r"(?i)\b(?:CN|OU|DC|O|UID)=[^,\n\"=]+(?:\s*,\s*" + mid + r")*\s*,\s*" + last)
        inner = re.compile(r"(?i)\b(CN|OU|DC|O|L|ST|C|UID)=([^,\n\"=]+)")

        def _r(m):
            if all(v.strip() == S for _, v in inner.findall(m.group(0))):
                return m.group(0)
            self.hit("ldap-dn", m.group(0))
            return inner.sub(lambda x: f"{x.group(1)}={S}", m.group(0))
        return rx.sub(_r, t)

    def r_windows_user(self, t):
        rx = re.compile(r"(?<![\\:\w/])([A-Z][A-Z0-9-]{1,14})\\([A-Za-z][\w.$-]{0,63})(?![\\\w])")

        def _r(m):
            if m.group(1) in REGISTRY_KEYS:
                return m.group(0)
            self.hit("domain-user", m.group(0))
            return f"{S}\\{S}"
        return rx.sub(_r, t)

    def r_home_paths(self, t):
        rx = re.compile(r"(?i)(/home/|/Users/|/var/home/|[A-Z]:\\Users\\|[A-Z]:/Users/)([^/\\\s\"']+)")

        def _r(m):
            if m.group(2) == S or m.group(2).lower() in {"public", "default", "shared", "all users"}:
                return m.group(0)
            self.hit("username-in-path", m.group(2))
            return m.group(1) + S
        return rx.sub(_r, t)

    def r_shell_prompt(self, t):
        rx = re.compile(r"(?m)^(\s*(?:\([^)\n]*\)\s*)?\[?)([\w.-]+)@([\w.-]+)(?=[:\s\]])")

        def _r(m):
            self.hit("shell-prompt", f"{m.group(2)}@{m.group(3)}")
            return f"{m.group(1)}{S}@{S}"
        return rx.sub(_r, t)

    def r_mac(self, t):
        return self.sub(t, "mac", r"(?<![\w:-])(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}(?![\w:-])")

    def r_uuid(self, t):
        return self.sub(t, "uuid", r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b")

    @staticmethod
    def _is_netmask(ip):
        n = int(ip)
        if n == 0:
            return False
        inv = (~n) & 0xFFFFFFFF
        return (inv & (inv + 1)) == 0 and str(ip).startswith("255.")

    def r_ipv4(self, t):
        rx = re.compile(r"(?<![\w.])((?:\d{1,3}\.){3}\d{1,3})(/\d{1,2})?(?!\.?\w)")

        def _r(m):
            try:
                ip = ipaddress.IPv4Address(m.group(1))
            except ValueError:
                return m.group(0)
            if self.allow.ip_kept(ip) or self._is_netmask(ip):
                return m.group(0)
            self.hit("ipv4" if not m.group(2) else "subnet", m.group(0))
            return S + (m.group(2) or "")
        return rx.sub(_r, t)

    def r_ipv6(self, t):
        rx = re.compile(r"(?<![\w:.])((?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4})(/\d{1,3})?(?![\w:])")

        def _r(m):
            try:
                ip = ipaddress.IPv6Address(m.group(1))
            except ValueError:
                return m.group(0)
            if self.allow.ip_kept(ip):
                return m.group(0)
            self.hit("ipv6", m.group(0))
            return S + (m.group(2) or "")
        return rx.sub(_r, t)

    def r_domains(self, t):
        label = r"[A-Za-z0-9_](?:[A-Za-z0-9_-]{0,61}[A-Za-z0-9])?"
        rx = re.compile(r"(?<![\w.@-])((?:" + label + r"\.)+[A-Za-z][A-Za-z0-9-]{1,62})(?![\w-]|\.[A-Za-z0-9])")

        def _r(m):
            name = m.group(1)
            labels = name.split(".")
            tld = labels[-1].lower()
            suffix = self.allow.domain_suffix(name)  # tenant part is private even on public clouds
            if suffix:
                self.hit("hostname", name)
                return S + suffix
            if self.allow.domain_kept(name):
                return name
            if tld in INTERNAL_TLDS:
                self.hit("hostname", name)
                return S
            if tld in PUBLIC_TLDS:
                if tld in AMBIGUOUS_TLDS and (len(labels) == 2 or self.check):
                    self.review[name] = self.review.get(name, 0) + 1
                    return name
                self.hit("hostname", name)
                return S
            return name
        return rx.sub(_r, t)

    def r_terms(self, t):
        for raw, rx in self.terms:
            def _r(m, raw=raw):
                if not m.group(0) or S in m.group(0):
                    return m.group(0)
                self.hit("company-term", m.group(0))
                return S
            t = rx.sub(_r, t)
        return t

    @staticmethod
    def _entropy(s):
        freq = {c: s.count(c) for c in set(s)}
        return -sum(f / len(s) * math.log2(f / len(s)) for f in freq.values())

    def r_high_entropy(self, t):
        rx = re.compile(r"(?<![A-Za-z0-9+=_-])[A-Za-z0-9+=_-]{32,}(?![A-Za-z0-9+=_-])")

        def _r(m):
            s = m.group(0)
            is_hex = re.fullmatch(r"[0-9a-fA-F]+", s) is not None
            mixed = re.search(r"[A-Za-z]", s) and re.search(r"\d", s)
            if is_hex or (mixed and self._entropy(s) >= 4.0):
                self.hit("high-entropy-string", s[:12] + "...")
                return S
            return s
        return rx.sub(_r, t)

    # ---- pipeline ----------------------------------------------------------

    def run(self, text):
        t = text.replace(TOKEN, S)
        for i, k in enumerate(self.keep):
            t = t.replace(k, f"\x00K{i}\x00")
        for rule in (self.r_pem, self.r_known_tokens, self.r_auth_header, self.r_url_creds,
                     self.r_kv_secrets, self.r_arn, self.r_email, self.r_ldap_dn,
                     self.r_windows_user, self.r_home_paths, self.r_shell_prompt, self.r_mac,
                     self.r_uuid, self.r_ipv4, self.r_ipv6, self.r_domains, self.r_terms,
                     self.r_high_entropy):
            t = rule(t)
        # <redacted>.<redacted>-<redacted>  ->  <redacted>
        t = re.sub(re.escape(S) + r"(?:[._-]" + re.escape(S) + r")+", S, t)
        for i, k in enumerate(self.keep):
            t = t.replace(f"\x00K{i}\x00", k)
        return t.replace(S, TOKEN)

    def report_text(self):
        lines = ["get-help redaction report (LOCAL ONLY - contains private values, never share)", ""]
        if self.found:
            lines.append(f"Redacted ({sum(self.found.values())} hits, {len(self.found)} unique):")
            for (cat, val), n in self.found.items():
                lines.append(f"  [{cat}] {val}" + (f"  (x{n})" if n > 1 else ""))
        else:
            lines.append("Redacted: nothing")
        if self.review:
            lines += ["", "Review by hand - might be hostnames/domains (left as-is):"]
            lines += [f"  {name}" for name in self.review]
        return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------- cli

def read_input(path):
    if path == "-":
        return sys.stdin.read()
    return Path(path).read_text(encoding="utf-8", errors="replace")


def main():
    ap = argparse.ArgumentParser(description="Redact private data with <redacted>.")
    ap.add_argument("command", choices=["redact", "check"])
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    ap.add_argument("--report")
    ap.add_argument("--terms", default=str(DEFAULT_TERMS))
    ap.add_argument("--allow", default=str(DEFAULT_ALLOW))
    ap.add_argument("--keep", action="append", default=[], metavar="TEXT",
                    help="exact text you checked and know is public; never redacted (repeatable)")
    a = ap.parse_args()

    terms = load_lines(a.terms)
    if not terms:
        print(f"warning: no company terms loaded from {a.terms} - names, app names and "
              "internal domains will only be caught by the agent's manual pass.", file=sys.stderr)
    allow = load_lines(a.allow)
    if allow is None:
        print(f"warning: allowlist not found: {a.allow}", file=sys.stderr)

    r = Redactor(terms, allow, check=(a.command == "check"), keep=a.keep)
    out = r.run(read_input(a.input))
    report = r.report_text()
    if a.report:
        Path(a.report).write_text(report, encoding="utf-8")

    if a.command == "redact":
        if a.output:
            Path(a.output).write_text(out, encoding="utf-8")
        else:
            sys.stdout.write(out)
        print(f"redact: {sum(r.found.values())} hits, {len(r.review)} items to review by hand"
              + (f" - report: {a.report}" if a.report else ""), file=sys.stderr)
        return 0

    # check
    if r.found:
        print("CHECK FAILED - private data still present:", file=sys.stderr)
        for (cat, val), _ in r.found.items():
            print(f"  [{cat}] {val}", file=sys.stderr)
        return 1
    if r.review:
        print("CHECK PASSED with items to review by hand (could be hostnames):", file=sys.stderr)
        for name in r.review:
            print(f"  {name}", file=sys.stderr)
        return 0
    print("CHECK PASSED", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
