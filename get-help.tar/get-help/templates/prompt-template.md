I'm working in a private, restricted company environment and I'm stuck on a problem. Please help me solve it.

Note: private details (hostnames, IP addresses, domains, people, internal app names, credentials and similar) were replaced with <redacted> before sending. Each <redacted> can be a different value; the text around it says what it is. Please don't ask for the hidden values. When your answer needs one, write a clear placeholder such as <HOST>, <IP>, <NAMESPACE> or <USER> so I can fill it in.

## Goal
{{What I am trying to achieve, in 1-3 sentences.}}

## Problem
{{What is going wrong: expected result vs. actual result. When it started, how often it happens, what changed recently.}}

## Environment
{{Public facts only: OS and version, product and tool versions, platform (Kubernetes/OpenShift/VM/bare metal/cloud), architecture, network setup described in words (e.g. "app server and DB server are on different subnets behind a firewall").}}

## Error output / logs
```
{{The exact error and the relevant log lines only, trimmed, redacted.}}
```

## Relevant configuration / code
```
{{The smallest config or code needed to understand the problem, redacted. Leave this section out if it isn't needed.}}
```

## What I've already tried
{{Each attempt and its result.}}

## Constraints
{{Things the answer must respect, e.g. no internet access (air-gapped), can't upgrade X, no cluster-admin, change window, company policy. Leave this section out if there are none.}}

## What I need from you
{{The specific question(s). Ask for: the most likely root cause, step-by-step commands to check and fix it, and how to verify the fix.}}
