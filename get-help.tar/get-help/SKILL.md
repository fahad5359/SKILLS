---
name: get-help
description: Turn the problem you (the private agent) are stuck on into one ready-to-copy prompt for a stronger PUBLIC AI agent, with all private company data (names, app names, IPs, subnets, domains, hostnames, users, credentials, IDs and more) replaced by <redacted>. Use when the user says "get-help", "get help", "ask a public agent", "we're stuck, make a prompt for ChatGPT/Claude/Gemini/Grok", "sanitize this for outside help", or "redact this issue". The skill only OUTPUTS a prompt; it never sends anything anywhere.
---

# get-help

You are running inside a PRIVATE work environment. The operator wants help from a stronger public AI
agent, but nothing private may leave. Your job: build the best possible problem description, remove
every private detail, and output **one prompt** that the operator copies and pastes by hand.

## Hard rules

1. **Never send anything.** Do not call web, search, fetch, upload, MCP, email or chat tools while using
   this skill. You only read local context, write local files and print the prompt.
2. **Every private value becomes exactly `<redacted>`.** No other placeholder style
   (no `<redacted:host-1>`, no `<HOST>`, no fake names, no `xxx`).
3. **When unsure whether something is private, redact it.** Leaking is much worse than over-redacting.
4. **Keep public facts** so the public agent can actually help: public product names and versions,
   OS versions, public error codes and messages, standard ports, standard file paths
   (`/etc/nginx/nginx.conf`), Kubernetes kinds, CLI flags, public registries and vendor domains,
   CIDR prefix lengths (`<redacted>/24`).
5. **Your final message is ONLY the prompt**, in a single fenced ```text code block. No preface, no
   summary, no explanation after it. (The one exception is step 7: the check fails.)

## What counts as private

- People: names, usernames, emails, phone numbers, employee IDs, team names.
- Company: company name and short names, internal app, service and product names and codenames,
  customer and partner names, project names, business data, internal jargon that identifies the company.
- Network: IPs (v4/v6), subnets, MAC addresses, VLAN IDs, hostnames (also short ones without dots, like
  `prdapp01`), internal and external company domains, URLs pointing to them, DNS zones, firewall object
  names, AD/LDAP domains and DNs.
- Platform: cluster names, namespaces, project names, datacenter/site/region names, cloud account,
  subscription, tenant and project IDs, ARNs, bucket names, repo and group paths, image names in
  private registries.
- Secrets: passwords, tokens, API keys, certificates, private keys, connection strings, cookies,
  session IDs, license keys, high-entropy strings.
- Identifiers: ticket and incident numbers, UUIDs that point to real resources, serial numbers, asset tags.
- File paths that contain any of the above (home folders with usernames, paths with app names).

## Workflow

Find this skill's folder (the directory containing this SKILL.md); it is called `SKILL_DIR` below.
Use `python3` (or `python` on Windows). Working files go to `~/.get-help/` (create it if missing).

### 1. Understand the problem

Use what you already have: this conversation, the errors you saw, the files and commands you worked
with, what you already tried. Re-read the relevant logs/configs if needed. If you can't tell what the
problem or the question is, ask the operator **one** short question, then continue.

### 2. Write the raw draft

Fill `SKILL_DIR/templates/prompt-template.md` and save it to `~/.get-help/raw.md`. Remove the `{{...}}`
instructions; drop optional sections that would be empty. While writing:

- **Describe roles in words**, because every hidden value looks the same:
  "the app server (`<redacted>`) can't reach the database server (`<redacted>`) on port 5432",
  "the ingress host for the payments app" -> "the ingress host for the main web app".
- **Generalise instead of copying**: describe internal apps by what they do ("an internal Java REST
  API"), not by name.
- **Logs**: include the first real error plus a few lines of context; cut repeated or unrelated lines.
- **Code/config**: only the smallest part needed. Rename company-specific identifiers in code to
  generic ones (`AcmeBillingClient` -> `<redacted>` or describe it). Never include whole proprietary files.
- **Already tried**: list each attempt and what happened. This saves the most time.
- **Ask a precise question** at the end.
- Keep it focused: usually under ~1500 words.

### 3. Script redaction

```bash
python3 "SKILL_DIR/scripts/redact.py" redact ~/.get-help/raw.md -o ~/.get-help/redacted.md --report ~/.get-help/report.txt
```

The script catches: IPs, subnets, IPv6, MACs, emails, hostnames and domains (internal TLDs plus
public ones), usernames in paths and shell prompts, `DOMAIN\user`, LDAP DNs, ARNs, UUIDs, PEM blocks,
known token formats, `password=`/`token:`-style values, URL credentials, long random strings, and
everything in `SKILL_DIR/config/private-terms.txt`. Public items in
`SKILL_DIR/config/public-allowlist.txt` are kept.

If it warns that no company terms are loaded, your manual pass (step 4) must be extra careful.

### 4. Your manual pass (you are the second filter)

Read `~/.get-help/redacted.md` line by line. The script cannot know company words, so look for:
short hostnames without dots, app/service/cluster/namespace names, people and team names, customer names,
ticket IDs, internal URL paths, repo paths, image names, database/table/queue/topic names that
identify the business, anything in the "review by hand" list in `report.txt`, and anything else that
could identify the company. Replace each with `<redacted>` (edit the file).

Also fix **over-redaction**: if the script hid something clearly public (a public vendor domain, a
version number that looked like an IP), put it back.

Then re-read the prompt as the public agent would: is the problem understandable without the hidden
values? If not, add role descriptions in words (never the real values).

Save the result as `~/.get-help/prompt.md`.

### 5. Gate check

```bash
python3 "SKILL_DIR/scripts/redact.py" check ~/.get-help/prompt.md
```

- Exit code 0 -> go on. Look at any "review by hand" names it prints and redact them if private.
- Exit code 1 -> it lists what is still private. Fix `prompt.md` and run the check again.

### 6. Clean up

Delete `~/.get-help/raw.md` and `~/.get-help/redacted.md`. Keep `prompt.md` (the operator can copy it from the file)
and `report.txt` (local record of what was hidden; never paste it anywhere public).

### 7. Output

Print the contents of `~/.get-help/prompt.md` as your entire final message, inside one fenced
```text code block, and nothing else.

If the check still fails after 3 rounds of fixes, do NOT print the prompt. Instead print one line:
`get-help: check still fails - see ~/.get-help/report.txt and fix by hand.`

## No Python available?

Do steps 1, 2 and 4 by hand using the "What counts as private" list, plus everything in
`config/private-terms.txt`. Before output, search your draft yourself for: digits in `a.b.c.d` form,
`:` hex groups, `@`, `\`, `/home/` and `/Users/`, words ending in `.com .net .org .local .corp .internal .lan`
and the company's own domains, `password`, `secret`, `token`, `key`, `BEGIN`, and long random strings.
The final output rule (only the prompt) still applies.

## Setup for the operator (one time)

1. Copy the whole `get-help/` folder into your agent's skills folder
   (e.g. `~/.claude/skills/`, `.opencode/skills/`, or wherever your agent loads skills from).
2. Fill `config/private-terms.txt` with your company's names, domains, app names and naming patterns.
   This is the most important step.
3. Add public vendor domains you often mention to `config/public-allowlist.txt`.
